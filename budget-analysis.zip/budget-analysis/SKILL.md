---
name: budget-analysis
description: Analisa orçado versus realizado, atingimento, gap e ritmo necessário para atingir a meta.
---

# Objetivo
Analisa orçado versus realizado, atingimento, gap e ritmo necessário para atingir a meta.

# Procedimento
Obtenha orçamento e realizado na mesma unidade e período. Calcule gap = orçado - realizado; atingimento = realizado / orçado quando orçado positivo. Consolide valores antes de calcular percentuais. Diferencie meta mensal de meta proporcional oficial. Não trate ausência como zero.

# Regras obrigatórias
Use somente dados autorizados e respeite permissões na origem. Priorize indicadores oficiais. Informe fonte, data de referência, filtros e unidade de medida. Se faltarem dados, explicite a limitação e solicite apenas o necessário. Não invente números nem execute ações comerciais. Consulte `references/validacao.md` antes de finalizar.

# Formato de saída
Tabela de orçamento, realizado, atingimento e gap; comparação com meta proporcional se disponível; esforço restante.
