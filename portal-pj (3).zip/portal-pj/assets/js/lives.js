import { getJSON, url, el } from './utils.js';

export function liveStatus(live, now = Date.now()) {
  if (['live', 'ended', 'cancelled'].includes(live.status)) return live.status;
  if (now < Date.parse(live.startsAt)) return 'upcoming';
  return now < Date.parse(live.endsAt) ? 'live' : 'ended';
}

export function teamsURL(value) {
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'https:' && ['teams.microsoft.com', 'teams.live.com', 'teams.cloud.microsoft'].includes(parsed.hostname) && !parsed.username && !parsed.password ? parsed.href : null;
  } catch { return null; }
}

const labels = { live: 'Ao vivo', upcoming: 'Em breve', ended: 'Encerrada', cancelled: 'Cancelada' };
const dateFormat = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: 'long', year: 'numeric' });
const timeFormat = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', hour: '2-digit', minute: '2-digit' });
function schedule(live) {
  const start = new Date(live.startsAt), end = new Date(live.endsAt);
  return `${dateFormat.format(start)}, ${timeFormat.format(start)} → ${dateFormat.format(start) === dateFormat.format(end) ? '' : dateFormat.format(end) + ', '}${timeFormat.format(end)} · Horário de Brasília`;
}
function badge(state) { return el('span', `live-badge live-badge--${state}`, labels[state]); }
function link(text, href, cls = 'btn-brand') {
  const node = el('a', cls, text); node.href = href; return node;
}
function validLives(data) {
  if (!Array.isArray(data)) throw new Error('Agenda inválida');
  const ids = new Set();
  for (const live of data) {
    if (!live || typeof live.id !== 'string' || !live.id || ids.has(live.id) || typeof live.title !== 'string' || !live.title || !Number.isFinite(Date.parse(live.startsAt)) || !Number.isFinite(Date.parse(live.endsAt)) || Date.parse(live.endsAt) <= Date.parse(live.startsAt) || !['auto', 'live', 'ended', 'cancelled', undefined].includes(live.status)) throw new Error('Live inválida');
    ids.add(live.id);
  }
  return data.sort((a, b) => Date.parse(a.startsAt) - Date.parse(b.startsAt));
}

export async function initLives() {
  const list = document.querySelector('[data-lives-list]');
  const detail = document.querySelector('[data-live-detail]');
  let lives;
  let filter = 'all';
  let signature = '';
  const render = () => {
    const now = Date.now();
    const states = lives.map(live => liveStatus(live, now));
    const key = JSON.stringify([lives, states, filter]);
    if (signature === key) return;
    signature = key;
    const active = lives.filter((live, i) => states[i] === 'live');
    document.querySelectorAll('[data-live-indicator]').forEach(node => {
      node.hidden = active.length === 0;
      node.textContent = 'Ao vivo';
    });
    const banner = document.querySelector('[data-live-banner]');
    if (banner) {
      banner.hidden = active.length === 0;
      banner.replaceChildren();
      if (active.length) banner.append(badge('live'), el('span', '', active.length === 1 ? active[0].title : `${active.length} lives acontecendo agora`), link('Acompanhar →', url(active.length === 1 ? `pages/live.html?id=${encodeURIComponent(active[0].id)}` : 'pages/lives.html'), 'btn-light-custom'));
    }
    if (list) {
      list.replaceChildren();
      const selected = lives.filter(live => filter === 'all' || liveStatus(live, now) === filter);
      selected.sort((a, b) => (liveStatus(a, now) === 'live' ? 0 : 1) - (liveStatus(b, now) === 'live' ? 0 : 1));
      document.querySelector('[data-lives-count]').textContent = `${selected.length} ${selected.length === 1 ? 'live' : 'lives'}`;
      if (!selected.length) list.append(el('p', 'empty', lives.length ? 'Nenhuma live nesta categoria. Confira as outras abas.' : 'Novos encontros vêm aí. A programação será divulgada aqui.'));
      for (const live of selected) {
        const state = liveStatus(live, now);
        const card = el('article', `live-card ${state === 'live' ? 'live-card--active' : ''}`);
        card.append(badge(state), el('p', 'live-platform', 'Microsoft Teams'), el('h2', '', live.title), el('p', 'live-description', live.description || ''), el('p', 'live-schedule', schedule(live)));
        if (live.speaker) card.append(el('p', 'live-speaker', `Com ${live.speaker}`));
        card.append(link(state === 'live' ? 'Acompanhar live →' : 'Ver detalhes →', `live.html?id=${encodeURIComponent(live.id)}`, state === 'live' ? 'btn-brand' : 'btn-ghost'));
        list.append(card);
      }
    }
    if (detail) {
      detail.replaceChildren();
      const live = lives.find(item => item.id === new URLSearchParams(location.search).get('id'));
      if (!live) {
        detail.append(el('h1', '', 'Live não encontrada'), el('p', 'lead-copy', 'Este encontro não está disponível. Consulte a programação.'), link('Ver todas as lives →', 'lives.html'));
        return;
      }
      const state = liveStatus(live, now);
      document.title = `${live.title} | Lives Portal PJ`;
      detail.append(badge(state), el('p', 'live-platform', 'Encontro online · Microsoft Teams'), el('h1', '', live.title), el('p', 'lead-copy', live.description || ''), el('p', 'live-schedule', schedule(live)));
      if (live.speaker) detail.append(el('p', '', `Com ${live.speaker}`));
      const join = teamsURL(live.teamsUrl);
      if (state === 'live' || state === 'upcoming') {
        if (join) {
          const button = link('Entrar no Teams ↗', join);
          button.target = '_blank'; button.rel = 'noopener noreferrer';
          detail.append(button, el('p', 'live-help', 'O Teams será aberto em uma nova aba. Antes do horário, aguarde a liberação do organizador.'));
        } else detail.append(el('p', 'live-notice', 'O link de acesso será disponibilizado em breve.'));
      } else detail.append(el('p', 'live-notice', state === 'ended' ? 'Esta live já foi encerrada. Confira os próximos encontros na programação.' : 'Esta live foi cancelada. Confira outros encontros na programação.'));
    }
  };
  const refresh = async () => {
    try {
      lives = validLives(await getJSON(`data/lives.json?t=${Date.now()}`));
      render();
      document.querySelector('[data-lives-error]')?.setAttribute('hidden', '');
    } catch {
      if (lives) render();
      const error = document.querySelector('[data-lives-error]');
      if (error) { error.hidden = false; error.textContent = lives ? 'Não foi possível atualizar a programação. Os últimos dados disponíveis estão sendo exibidos.' : 'Não foi possível carregar as lives. Tente recarregar a página.'; }
      if (!lives && list) list.replaceChildren();
      if (!lives && detail) detail.replaceChildren(el('h1', '', 'Lives indisponíveis'));
    }
  };
  document.querySelectorAll('[data-live-filter]').forEach(button => button.addEventListener('click', () => {
    filter = button.dataset.liveFilter;
    document.querySelectorAll('[data-live-filter]').forEach(item => item.setAttribute('aria-pressed', String(item === button)));
    if (lives) render();
  }));
  await refresh();
  setInterval(() => { if (lives) render(); }, 1000);
  setInterval(refresh, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
}
