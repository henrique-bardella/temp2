# Portal PJ

## Lives no Teams

Abra `pages/lives.html` para consultar a agenda. Cada encontro tem uma página em `pages/live.html?id=ID`, com acesso ao Teams em nova aba. O menu destaca lives em andamento, e a página inicial exibe uma chamada quando há uma live ativa.

Cadastre os encontros em `data/lives.json` (inicialmente vazio), usando este formato:

```json
[
  {
    "id": "encontro-pj",
    "title": "Encontro do Portal PJ",
    "description": "Temas e orientações para o dia a dia.",
    "speaker": "Equipe Portal PJ",
    "startsAt": "2026-10-15T14:00:00-03:00",
    "endsAt": "2026-10-15T15:00:00-03:00",
    "status": "auto",
    "teamsUrl": ""
  }
]
```

Substitua as datas e preencha `teamsUrl` com o link HTTPS real do convite do Teams. Sem link, a página informa que o acesso será disponibilizado em breve. Use IDs únicos e datas ISO com fuso horário; o fim deve ser posterior ao início.

Com `status: "auto"` (ou sem status), o indicador usa o horário do dispositivo e o intervalo cadastrado: próxima antes do início, ao vivo durante o intervalo e encerrada após o fim. Ele **não consulta a transmissão no Teams**. Para controlar atrasos, encerramentos antecipados ou cancelamentos, use `live`, `ended` ou `cancelled` e atualize o arquivo publicado. `live` permanece ativo até uma nova alteração. A agenda é consultada a cada 60 segundos e ao retornar à aba; transições de horário são verificadas a cada segundo. Os horários são exibidos no fuso de Brasília.

Portal institucional estático, responsivo e orientado a dados, construído com HTML5, Bootstrap 5, CSS e JavaScript Vanilla ES Modules. Não há build, Node ou npm.

## Executar

Copie a pasta para `C:\xampp\htdocs\portal-pj\`, inicie o Apache no XAMPP e acesse `http://localhost/portal-pj/`. Não abra via `file://`: componentes e JSON usam `fetch()`.

Para desenvolvimento, qualquer servidor HTTP estático serve (por exemplo, `python -m http.server 8000`).

## Estrutura

- `components/`: header, footer e overlay de busca compartilhados.
- `assets/css/`: tokens e estilos customizados.
- `assets/js/`: módulos de componentes, navegação, busca, carrossel, soluções e documentos.
- `assets/images/`: imagens locais; substitua mantendo os caminhos ou atualize os JSON.
- `data/solutions.json`: adicione soluções e seus benefícios.
- `data/documents.json`: adicione documentos e caminhos em `pdfs/`.
- `data/search-index.json`: itens pesquisáveis.
- `pages/`: páginas internas.

Os PDFs de demonstração não estão incluídos; coloque os arquivos em `pdfs/` com os nomes configurados em `documents.json`. O formulário de contato apenas valida os campos até que uma URL de backend seja configurada.

## Publicação e URLs

A aplicação funciona em `/portal-pj/`. O `.htaccess` inclui uma regra opcional para `/portal-pj/solucoes/capital-giro`; requer `mod_rewrite`. A URL com query string (`pages/solucao.html?id=capital-giro`) funciona independentemente dessa regra.
