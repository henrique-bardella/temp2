const API_VALIDACAO = (() => {
  const origin = window.location.origin;
  const path = window.location.pathname || "";
  if (path.includes("/Prospecta_PJ/")) {
    return `${origin}/Prospecta_PJ/api/validacao_cnpj.php`;
  }
  const host = window.location.hostname || "localhost";
  return `http://${host}/Prospecta_PJ/api/validacao_cnpj.php`;
})();

const formValidacao = document.getElementById("validacao-form");
const inputValidacaoCnpj = document.getElementById("validacao-cnpj");
const btnValidarCnpj = document.getElementById("btn-validar-cnpj");
const btnLimparValidacao = document.getElementById("btn-limpar-validacao");
const validacaoAlert = document.getElementById("validacao-alert");
const validacaoResultado = document.getElementById("validacao-resultado");

if (inputValidacaoCnpj) {
  inputValidacaoCnpj.addEventListener("input", (event) => {
    event.target.value = aplicarMascaraCnpj(event.target.value);
  });
}

if (formValidacao) {
  formValidacao.addEventListener("submit", (event) => {
    event.preventDefault();
    validarCnpjNoBanco();
  });
}

if (btnLimparValidacao) {
  btnLimparValidacao.addEventListener("click", () => {
    if (formValidacao) formValidacao.reset();
    limparAlert(validacaoAlert);
    validacaoResultado.innerHTML = '<p class="text-muted">Nenhuma validação realizada ainda.</p>';
  });
}

function aplicarMascaraCnpj(valor) {
  const digits = valor.replace(/\D/g, "").slice(0, 14);
  return digits
    .replace(/(\d{2})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1/$2")
    .replace(/(\d{4})(\d{1,2})$/, "$1-$2");
}

function limparCnpj(valor) {
  return String(valor || "").replace(/\D/g, "");
}

function toggleLoading(botao, ativo) {
  const label = botao.querySelector(".btn-label");
  const spinner = botao.querySelector(".spinner-border");
  if (ativo) {
    botao.setAttribute("disabled", "disabled");
    label.classList.add("d-none");
    spinner.classList.remove("d-none");
  } else {
    botao.removeAttribute("disabled");
    label.classList.remove("d-none");
    spinner.classList.add("d-none");
  }
}

function exibirAlert(container, tipo, mensagem) {
  container.classList.remove("d-none", "alert-success", "alert-danger", "alert-warning", "alert-info");
  container.classList.add(`alert-${tipo}`);
  container.textContent = mensagem;
}

function limparAlert(container) {
  container.classList.add("d-none");
  container.textContent = "";
}

function criarListaDados(itens) {
  return (
    itens
      .filter((item) => item[1] && item[1] !== "-")
      .map(
        ([label, valor]) => `
        <div class="data-item">
          <div class="data-label">${label}</div>
          <div class="data-value">${valor}</div>
        </div>
      `
      )
      .join("") || '<p class="text-muted">Nenhuma informação disponível.</p>'
  );
}

async function validarCnpjNoBanco() {
  limparAlert(validacaoAlert);
  const cnpj = limparCnpj(inputValidacaoCnpj?.value || "");
  if (cnpj.length !== 14) {
    exibirAlert(validacaoAlert, "warning", "CNPJ inválido. Informe 14 dígitos.");
    return;
  }

  toggleLoading(btnValidarCnpj, true);
  exibirAlert(validacaoAlert, "info", "Consultando validação...");

  try {
    const response = await fetch(`${API_VALIDACAO}?cnpj=${encodeURIComponent(cnpj)}`);
    const texto = await response.text();
    if (!response.ok) {
      exibirAlert(validacaoAlert, "danger", `Erro na API: ${response.status} ${texto.slice(0, 120)}`);
      return;
    }
    const data = parseJsonSeguro(texto);
    if (!data) {
      exibirAlert(validacaoAlert, "danger", "Resposta inválida da API.");
      return;
    }

    if (data.is_indicado) {
      exibirAlert(validacaoAlert, "success", "CNPJ já teve indicação registrada.");
      renderResultado(data.data || {});
    } else {
      exibirAlert(validacaoAlert, "warning", "CNPJ ainda não teve indicação.");
      renderResultado({});
    }
  } catch (error) {
    exibirAlert(validacaoAlert, "danger", `Erro de rede: ${error?.message || "desconhecido"}.`);
  } finally {
    toggleLoading(btnValidarCnpj, false);
  }
}

function parseJsonSeguro(texto) {
  const limpo = String(texto || "").replace(/^\uFEFF/, "").trim();
  if (!limpo) return null;
  try {
    return JSON.parse(limpo);
  } catch (e) {
    return null;
  }
}

function renderResultado(data) {
  const itens = Object.keys(data || {}).map((key) => [formatarLabel(key), data[key]]);
  validacaoResultado.innerHTML =
    itens.length > 0 ? criarListaDados(itens) : '<p class="text-muted">Nenhuma informação disponível.</p>';
}

function formatarLabel(texto) {
  return String(texto || "")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}
