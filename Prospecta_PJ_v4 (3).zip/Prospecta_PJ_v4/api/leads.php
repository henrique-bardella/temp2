﻿<?php
// api/leads.php

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function getJsonBody() {
    $raw = file_get_contents('php://input');
    if (!$raw) {
        return [];
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function onlyDigits($value) {
    return preg_replace('/\D/', '', (string) $value);
}

function nullableTrimmedString($value) {
    $normalized = trim((string) ($value ?? ''));
    return $normalized === '' || $normalized === '-' ? null : $normalized;
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
    $cnpj = isset($_GET['cnpj']) ? onlyDigits($_GET['cnpj']) : '';
    $limit = isset($_GET['limit']) ? (int) $_GET['limit'] : 50;
    $offset = isset($_GET['offset']) ? (int) $_GET['offset'] : 0;

    if ($id > 0) {
        $stmt = $pdo->prepare('SELECT * FROM leads WHERE id = :id');
        $stmt->execute([':id' => $id]);
        $lead = $stmt->fetch();
        if (!$lead) {
            respond(['error' => 'Lead não encontrado.'], 404);
        }
        respond($lead);
    }

    if ($cnpj) {
        $stmt = $pdo->prepare('SELECT * FROM leads WHERE cnpj = :cnpj ORDER BY created_at DESC');
        $stmt->execute([':cnpj' => $cnpj]);
        $leads = $stmt->fetchAll();
        respond($leads);
    }

    $limit = max(1, min($limit, 200));
    $offset = max(0, $offset);

    $stmt = $pdo->prepare('SELECT * FROM leads ORDER BY created_at DESC LIMIT :limit OFFSET :offset');
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    respond($stmt->fetchAll());
}

if ($method === 'POST') {
    $data = getJsonBody();
    $cnpj = onlyDigits($data['cnpj'] ?? '');

    if (strlen($cnpj) !== 14) {
        respond(['error' => 'CNPJ inválido.'], 400);
    }

    $payload = [
        'cnpj' => $cnpj,
        'empresa' => trim((string) ($data['empresa'] ?? '')),
        'telefone' => trim((string) ($data['telefone'] ?? '')),
        'endereco' => trim((string) ($data['endereco'] ?? '')),
        'escritorio' => trim((string) ($data['escritorio'] ?? '')),
        'agencia_gerente' => trim((string) ($data['agencia_gerente'] ?? '')),
        'codigo_funcional' => trim((string) ($data['codigo_funcional'] ?? '')),
        'nome_completo' => trim((string) ($data['nome_completo'] ?? '')),
        'email_gerente' => trim((string) ($data['email_gerente'] ?? '')),
        'recebedor_codigo_funcional' => nullableTrimmedString($data['recebedor_codigo_funcional'] ?? null),
        'recebedor_nome_completo' => nullableTrimmedString($data['recebedor_nome_completo'] ?? null),
        'recebedor_email' => nullableTrimmedString($data['recebedor_email'] ?? null),
        'email_agencia' => trim((string) ($data['email_agencia'] ?? '')),
        'banco_atual' => trim((string) ($data['banco_atual'] ?? '')),
        'grupo_economico' => trim((string) ($data['grupo_economico'] ?? '')),
        'faturamento_anual' => isset($data['faturamento_anual']) ? (float) $data['faturamento_anual'] : null,
        'comentario' => trim((string) ($data['comentario'] ?? '')),
        'agencia' => trim((string) ($data['agencia'] ?? '')),
        'municipio_uf' => trim((string) ($data['municipio_uf'] ?? '')),
        'distancia_km' => isset($data['distancia_km']) ? (float) $data['distancia_km'] : null,
        'status' => trim((string) ($data['status'] ?? 'enviado')),
        'data_envio' => $data['data_envio'] ?? date('Y-m-d H:i:s'),
    ];

    if ($payload['empresa'] === '') {
        respond(['error' => 'Empresa é obrigatória.'], 400);
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM leads WHERE cnpj = :cnpj');
    $stmt->execute([':cnpj' => $payload['cnpj']]);
    if ((int) $stmt->fetchColumn() > 0) {
        respond(['error' => 'CNPJ já cadastrado.'], 409);
    }

    $stmt = $pdo->prepare(
        'INSERT INTO leads (
            cnpj, empresa, telefone, endereco, escritorio, agencia_gerente, codigo_funcional,
            nome_completo, email_gerente, recebedor_codigo_funcional, recebedor_nome_completo,
            recebedor_email, email_agencia, banco_atual, grupo_economico,
            faturamento_anual, comentario, agencia, municipio_uf, distancia_km, status, data_envio
        ) VALUES (
            :cnpj, :empresa, :telefone, :endereco, :escritorio, :agencia_gerente, :codigo_funcional,
            :nome_completo, :email_gerente, :recebedor_codigo_funcional, :recebedor_nome_completo,
            :recebedor_email, :email_agencia, :banco_atual, :grupo_economico,
            :faturamento_anual, :comentario, :agencia, :municipio_uf, :distancia_km, :status, :data_envio
        )'
    );

    $stmt->execute([
        ':cnpj' => $payload['cnpj'],
        ':empresa' => $payload['empresa'],
        ':telefone' => $payload['telefone'],
        ':endereco' => $payload['endereco'],
        ':escritorio' => $payload['escritorio'],
        ':agencia_gerente' => $payload['agencia_gerente'],
        ':codigo_funcional' => $payload['codigo_funcional'],
        ':nome_completo' => $payload['nome_completo'],
        ':email_gerente' => $payload['email_gerente'],
        ':recebedor_codigo_funcional' => $payload['recebedor_codigo_funcional'],
        ':recebedor_nome_completo' => $payload['recebedor_nome_completo'],
        ':recebedor_email' => $payload['recebedor_email'],
        ':email_agencia' => $payload['email_agencia'],
        ':banco_atual' => $payload['banco_atual'],
        ':grupo_economico' => $payload['grupo_economico'],
        ':faturamento_anual' => $payload['faturamento_anual'],
        ':comentario' => $payload['comentario'],
        ':agencia' => $payload['agencia'],
        ':municipio_uf' => $payload['municipio_uf'],
        ':distancia_km' => $payload['distancia_km'],
        ':status' => $payload['status'],
        ':data_envio' => $payload['data_envio'],
    ]);

    respond(['id' => (int) $pdo->lastInsertId(), 'message' => 'Lead salvo.'], 201);
}

if ($method === 'PUT' || $method === 'PATCH') {
    $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
    if ($id <= 0) {
        respond(['error' => 'Informe o id do lead.'], 400);
    }

    $data = getJsonBody();
    $fields = [
        'empresa', 'telefone', 'endereco', 'escritorio', 'agencia_gerente', 'codigo_funcional',
        'nome_completo', 'email_gerente', 'recebedor_codigo_funcional', 'recebedor_nome_completo',
        'recebedor_email', 'email_agencia', 'banco_atual', 'grupo_economico',
        'faturamento_anual', 'comentario', 'agencia', 'municipio_uf', 'distancia_km', 'status', 'data_envio'
    ];

    $set = [];
    $params = [':id' => $id];

    foreach ($fields as $field) {
        if (array_key_exists($field, $data)) {
            $set[] = "$field = :$field";
            $params[":$field"] = in_array($field, [
                'recebedor_codigo_funcional', 'recebedor_nome_completo', 'recebedor_email'
            ], true) ? nullableTrimmedString($data[$field]) : $data[$field];
        }
    }

    if (isset($data['cnpj'])) {
        $cnpj = onlyDigits($data['cnpj']);
        if (strlen($cnpj) !== 14) {
            respond(['error' => 'CNPJ inválido.'], 400);
        }
        $set[] = 'cnpj = :cnpj';
        $params[':cnpj'] = $cnpj;
    }

    if (empty($set)) {
        respond(['error' => 'Nenhum campo para atualizar.'], 400);
    }

    $sql = 'UPDATE leads SET ' . implode(', ', $set) . ' WHERE id = :id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    respond(['message' => 'Lead atualizado.']);
}

if ($method === 'DELETE') {
    $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
    if ($id <= 0) {
        respond(['error' => 'Informe o id do lead.'], 400);
    }
    $stmt = $pdo->prepare('DELETE FROM leads WHERE id = :id');
    $stmt->execute([':id' => $id]);
    respond(['message' => 'Lead removido.']);
}

respond(['error' => 'Método não suportado.'], 405);
