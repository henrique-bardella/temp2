﻿<?php
// api/config.php
// Ajuste com suas credenciais do MySQL no XAMPP.

return [
    'db_host' => '127.0.0.1',
    'db_name' => 'prospecta',
    'db_user' => 'root',
    'db_pass' => 'admin',
    'db_port' => 3306,
    'db_charset' => 'utf8mb4',
    // View usada para validar se o CNPJ virou cliente.
    // Ajuste para o nome da view no seu banco.
    'lead_view' => 'vw_leads_clientes',
];
