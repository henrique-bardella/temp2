<?php
// api/validacao_cnpj.php

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function onlyDigits($value) {
    return preg_replace('/\D/', '', (string) $value);
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respond(['error' => 'Método não suportado.'], 405);
}

$cnpj = isset($_GET['cnpj']) ? onlyDigits($_GET['cnpj']) : '';
if (strlen($cnpj) !== 14) {
    respond(['error' => 'CNPJ inválido.'], 400);
}

try {
    $stmt = $pdo->prepare(
        "SELECT cnpj, empresa, created_at FROM leads WHERE cnpj = :cnpj ORDER BY created_at DESC LIMIT 1"
    );
    $stmt->execute([':cnpj' => $cnpj]);
    $row = $stmt->fetch();
    if (!$row) {
        respond(['cnpj' => $cnpj, 'is_indicado' => false, 'data' => null]);
    }
    respond(['cnpj' => $cnpj, 'is_indicado' => true, 'data' => $row]);
} catch (PDOException $e) {
    respond(['error' => 'Erro ao consultar as indicações.']);
}
