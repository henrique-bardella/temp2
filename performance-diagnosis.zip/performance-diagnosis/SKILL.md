---
name: performance-diagnosis
description: Identifica ofensores, destaques e concentração dos desvios financeiros por hierarquia.
---

# Objetivo
Identifica ofensores, destaques e concentração dos desvios financeiros por hierarquia.

# Procedimento
Calcule desvios por unidades mutuamente exclusivas. Ordene ofensores por gap positivo absoluto e destaques por excedente. Separe déficit bruto, excedentes e gap líquido. Compare histórico e indicadores de volume e mix quando disponíveis. Não confunda associação com causalidade.

# Regras obrigatórias
Use somente dados autorizados e respeite permissões na origem. Priorize indicadores oficiais. Informe fonte, data de referência, filtros e unidade de medida. Se faltarem dados, explicite a limitação e solicite apenas o necessário. Não invente números nem execute ações comerciais. Consulte `references/validacao.md` antes de finalizar.

# Formato de saída
Ranking de ofensores e destaques; contribuição financeira; hipóteses e evidências; recomendações.
