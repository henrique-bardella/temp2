import { url } from "./utils.js";
const insideSection = new Set([
  "solucoes.html",
  "solucao.html",
  "documentos.html",
  "sobre.html",
  "agendamentos.html",
]);
export async function loadComponents() {
  for (const [selector, file] of [
    ["#app-header", "components/header.html"],
    ["#app-footer", "components/footer.html"],
    ["#app-search", "components/search-overlay.html"],
  ]) {
    const node = document.querySelector(selector);
    if (!node) continue;
    try {
      const response = await fetch(url(file));
      if (!response.ok) throw new Error();
      node.innerHTML = await response.text();
    } catch {
      node.innerHTML = '<div class="empty">Componente indisponível.</div>';
    }
  }
  document
    .querySelectorAll("[data-route]")
    .forEach((link) => (link.href = url(link.dataset.route)));
  document
    .querySelectorAll("[data-logo]")
    .forEach((image) => (image.src = url("assets/images/logo-bradesco.png")));
  const page = location.pathname.split("/").pop() || "index.html";
  document
    .querySelectorAll(".nav-link")
    .forEach((link) => link.classList.remove("active"));
  const desktop = [
      ...document.querySelectorAll(".desktop-nav>.nav-link[data-route]"),
    ],
    current = desktop.find(
      (link) => new URL(link.href).pathname.split("/").pop() === page,
    );
  if (current) current.classList.add("active");
  if (page === "conteudos.html")
    document.querySelector(".nav-dropdown-trigger")?.classList.add("active");
  else if (page === "resultados.html")
    document.querySelector(".results-dropdown-trigger")?.classList.add("active");
  else if (insideSection.has(page))
    document
      .querySelector('.desktop-nav [data-section="pj"]')
      ?.classList.add("active");
  document
    .querySelectorAll("#mobileNav .nav-link[data-route]")
    .forEach((link) => {
      if (new URL(link.href).pathname.split("/").pop() === page)
        link.classList.add("active");
    });
}
