export const base = () => document.body.dataset.base || "./";
export const url = (p) => `${base()}${p}`;
export async function getJSON(path) {
  const r = await fetch(url(path));
  if (!r.ok) throw new Error(`Não foi possível carregar ${path}`);
  return r.json();
}
export const normalize = (s) =>
  (s || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
export const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text) n.textContent = text;
  return n;
};
