import { getJSON, url, el } from "./utils.js";
const card = (s) => {
  const col = el("div", "col-md-6 col-xl-4 solution-item");
  col.dataset.category = s.slugCategory;
  const art = el("article", "card-premium");
  const media = el("div", "card-media");
  const img = el("img");
  img.src = url(s.image);
  img.alt = "";
  img.loading = "lazy";
  img.onerror = () => img.remove();
  media.append(img);
  const body = el("div", "card-body-custom");
  body.append(
    el("span", "eyebrow", s.category),
    el("h3", "", s.title),
    el("p", "", s.shortDescription),
  );
  const a = el("a", "btn-ghost mt-2", "Conheça →");
  a.href = url(`pages/solucao.html?id=${s.id}`);
  body.append(a);
  art.append(media, body);
  col.append(art);
  return col;
};
export async function initSolutions() {
  const grid = document.querySelector("#solutionsGrid");
  if (!grid) return;
  try {
    const data = await getJSON("data/solutions.json");
    grid.replaceChildren(...data.map(card));
    document.querySelectorAll("[data-filter]").forEach((b) =>
      b.addEventListener("click", () => {
        document
          .querySelectorAll("[data-filter]")
          .forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        grid
          .querySelectorAll(".solution-item")
          .forEach(
            (c) =>
              (c.hidden =
                b.dataset.filter !== "all" &&
                c.dataset.category !== b.dataset.filter),
          );
      }),
    );
  } catch {
    grid.innerHTML =
      '<div class="empty">Soluções temporariamente indisponíveis.</div>';
  }
}
export async function initSolutionDetail() {
  const root = document.querySelector("#solutionDetail");
  if (!root) return;
  try {
    const all = await getJSON("data/solutions.json"),
      s = all.find(
        (x) => x.id === new URLSearchParams(location.search).get("id"),
      );
    if (!s) throw 0;
    document.title = `${s.title} | Portal PJ`;
    root.querySelector("[data-title]").textContent = s.title;
    root.querySelector("[data-subtitle]").textContent = s.shortDescription;
    root.querySelector("[data-description]").textContent = s.description;
    const benefits = root.querySelector("[data-benefits]");
    benefits.replaceChildren(
      ...s.benefits.map((x) => {
        const d = el("div", "col-md-4");
        d.innerHTML = `<div class="card-premium card-body-custom"><i class="bi bi-check-circle text-danger fs-3"></i><h3 class="mt-3">${x}</h3></div>`;
        return d;
      }),
    );
  } catch {
    root.innerHTML =
      '<section class="page-hero"><div class="container"><p class="eyebrow">Conteúdo não encontrado</p><h1>Esta solução não está disponível.</h1><a class="btn-brand mt-4" href="solucoes.html">Ver soluções →</a></div></section>';
  }
}
