import { getJSON, normalize, url, el } from "./utils.js";

const sources = [
  ["data/search-index.json", (items) => items],
  [
    "data/solutions.json",
    (items) =>
      items.map((item) => ({
        type: "Solução",
        title: item.title,
        description: item.shortDescription || item.description,
        keywords: [item.category, item.slugCategory, ...(item.benefits || [])],
        url: `pages/solucao.html?id=${item.id}`,
      })),
  ],
  [
    "data/documents.json",
    (items) =>
      items.map((item) => ({
        type: "Documento",
        title: item.title,
        description: item.description,
        keywords: [item.category, item.month, item.year, item.date],
        url: item.file,
      })),
  ],
  [
    "data/banners.json",
    (items) =>
      items.map((item) => ({
        type: "Destaque",
        title: item.title,
        description: item.subtitle,
        keywords: [item.eyebrow, item.buttonLabel],
        url: item.buttonUrl,
      })),
  ],
];

async function buildIndex() {
  const loaded = await Promise.allSettled(
    sources.map(async ([file, adapt]) => adapt(await getJSON(file))),
  );
  const unique = new Map();
  loaded
    .flatMap((source) => (source.status === "fulfilled" ? source.value : []))
    .forEach((item) => {
      const key = `${normalize(item.type)}|${normalize(item.title)}|${item.url}`;
      unique.set(key, item);
    });
  return [...unique.values()];
}

function renderResults(root, results) {
  root.replaceChildren();
  if (!results.length) {
    root.append(el("p", "text-white-50", "Nenhum resultado encontrado."));
    return;
  }
  const groups = results.reduce((map, item) => {
    const type = item.type || "Outros";
    if (!map.has(type)) map.set(type, []);
    map.get(type).push(item);
    return map;
  }, new Map());
  groups.forEach((items, type) => {
    root.append(el("h3", "eyebrow mt-4 mb-1", type));
    items.forEach((item) => {
      const link = el("a", "result-item");
      link.href = url(item.url);
      link.append(
        el("h4", "my-1", item.title),
        el("span", "text-white-50", item.description),
      );
      root.append(link);
    });
  });
}

export async function initSearch() {
  const overlay = document.querySelector(".search-overlay");
  const input = document.querySelector("#globalSearch");
  const output = document.querySelector("#searchResults");
  if (!overlay || !input || !output) return;
  const data = await buildIndex();
  const open = () => {
    overlay.classList.add("open");
    document.body.classList.add("search-open");
    setTimeout(() => input.focus(), 200);
  };
  const close = () => {
    overlay.classList.remove("open");
    document.body.classList.remove("search-open");
  };
  document
    .querySelectorAll(".search-trigger")
    .forEach((button) => button.addEventListener("click", open));
  document.querySelector(".search-close")?.addEventListener("click", close);
  addEventListener("keydown", (event) => event.key === "Escape" && close());
  input.addEventListener("input", () => {
    const query = normalize(input.value.trim());
    if (query.length < 2) {
      output.replaceChildren(
        el(
          "p",
          "text-white-50",
          "Digite pelo menos 2 caracteres para começar.",
        ),
      );
      return;
    }
    const results = data.filter((item) =>
      normalize(
        [item.title, item.description, ...(item.keywords || [])].join(" "),
      ).includes(query),
    );
    renderResults(output, results);
  });
}
