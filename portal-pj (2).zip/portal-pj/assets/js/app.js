import { loadComponents } from "./components.js";
import { initNavigation } from "./navigation.js";
import { initCarousel } from "./carousel.js";
import { initSearch } from "./search.js";
import { initSolutions, initSolutionDetail } from "./solutions.js";
import { initDocuments } from "./documents.js";
import { initVideo } from "./video.js";
await loadComponents();
initNavigation();
initCarousel();
initSearch();
initSolutions();
initSolutionDetail();
initDocuments();
initVideo();
const io = new IntersectionObserver(
  (es) =>
    es.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add("visible");
        io.unobserve(e.target);
      }
    }),
  { threshold: 0.12 },
);
document.querySelectorAll(".reveal").forEach((x) => io.observe(x));
