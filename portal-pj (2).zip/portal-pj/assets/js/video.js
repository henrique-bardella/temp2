export function initVideo() {
  const video = document.querySelector(".video-thumbnail");
  const playButton = document.querySelector("[data-video-play]");
  const media = video?.closest(".editorial-media");
  if (!video || !playButton || !media) return;

  const showFrame = () => {
    video.currentTime = Math.min(0.1, video.duration || 0.1);
  };
  if (video.readyState >= 1) showFrame();
  else video.addEventListener("loadedmetadata", showFrame, { once: true });

  playButton.addEventListener("click", () => {
    video.controls = true;
    media.classList.add("is-playing");
    video.play().catch(() => {});
  });

  video.addEventListener("ended", () => {
    video.controls = false;
    media.classList.remove("is-playing");
    showFrame();
  });
}
