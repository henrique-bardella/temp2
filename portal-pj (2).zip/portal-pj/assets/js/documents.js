import { getJSON, url, el, normalize } from "./utils.js";
export async function initDocuments() {
  const grid = document.querySelector("#documentsGrid");
  if (!grid) return;
  let docs = [];
  try {
    docs = await getJSON("data/documents.json");
  } catch {
    grid.innerHTML = '<div class="empty">Documentos indisponíveis.</div>';
    return;
  }
  const month = document.querySelector("#month"),
    year = document.querySelector("#year"),
    sort = document.querySelector("#sortDocs"),
    q = document.querySelector("#docSearch");
  [...new Set(docs.map((d) => d.year))].forEach((v) =>
    year.add(new Option(v, v)),
  );
  const render = () => {
    let list = docs.filter(
      (d) =>
        (!month.value || d.month == month.value) &&
        (!year.value || d.year == year.value) &&
        normalize(d.title + " " + d.description).includes(normalize(q.value)),
    );
    list.sort(
      (a, b) => (sort.value === "old" ? 1 : -1) * a.date.localeCompare(b.date),
    );
    grid.replaceChildren(
      ...list.map((d) => {
        const c = el("div", "col-md-6");
        c.innerHTML = `<article class="card-premium card-body-custom"><span class="eyebrow">${new Date(d.date + "T12:00").toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</span><h3 class="mt-3">${d.title}</h3><p>${d.description}</p><a class="btn-ghost mt-3" href="${url(d.file)}" target="_blank">Abrir PDF <span>↗</span></a></article>`;
        return c;
      }),
    );
    if (!list.length)
      grid.innerHTML = '<div class="empty">Nenhum documento encontrado.</div>';
  };
  [month, year, sort, q].forEach((x) => x.addEventListener("input", render));
  render();
}
