import { getJSON, url } from "./utils.js";

const DURATION = 7000;
const styles = `.hero-progress{position:absolute;z-index:3;left:max(calc((100vw - var(--max))/2),2rem);right:max(calc((100vw - var(--max))/2),2rem);bottom:2.25rem;display:grid;gap:.6rem;padding-right:130px}.hero-progress-item{height:18px;padding:8px 0;border:0;background:transparent;position:relative;overflow:hidden}.hero-progress-item:before,.hero-progress-item span{content:"";position:absolute;left:0;right:0;top:8px;height:2px}.hero-progress-item:before{background:rgba(255,255,255,.32)}.hero-progress-item span{background:#fff;transform:scaleX(0);transform-origin:left center}.hero-progress-item.is-complete span{transform:scaleX(1)}.hero-progress-item.is-running span{animation:hero-progress var(--hero-duration) linear forwards}.hero-copy-enter{animation:hero-copy-in .65s var(--ease) both}@keyframes hero-progress{from{transform:scaleX(0)}to{transform:scaleX(1)}}@keyframes hero-copy-in{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}@media(max-width:767px){.hero-progress{left:1.25rem;right:1.25rem;bottom:1.1rem;padding-right:110px;gap:.35rem}.hero-progress-item{height:14px;padding:6px 0}.hero-progress-item:before,.hero-progress-item span{top:6px}}@media(prefers-reduced-motion:reduce){.hero-copy-enter{animation:none}}`;

function createSlide(banner, index) {
  const slide = document.createElement("div");
  slide.className = `hero-slide${index === 0 ? " active" : ""}`;
  const image = document.createElement("img");
  image.src = url(banner.image);
  image.alt = banner.imageAlt || "";
  image.decoding = "async";
  slide.append(image);
  return slide;
}

function renderCopy(root, banner) {
  const content = document.createElement("div");
  content.className = "hero-copy-enter";
  const eyebrow = document.createElement("span");
  eyebrow.className = "eyebrow";
  eyebrow.textContent = banner.eyebrow;
  const title = document.createElement("h1");
  title.textContent = banner.title;
  const subtitle = document.createElement("p");
  subtitle.textContent = banner.subtitle;
  const button = document.createElement("a");
  button.className = "btn-light-custom mt-3";
  button.href = banner.buttonUrl;
  button.target = "_blank";
  button.rel = "noopener noreferrer";
  button.textContent = `${banner.buttonLabel} →`;
  content.append(eyebrow, title, subtitle, button);
  root.replaceChildren(content);
}

export async function initCarousel() {
  const hero = document.querySelector(".hero");
  const copyRoot = hero?.querySelector(".hero-content");
  if (!hero || !copyRoot) return;
  let banners;
  try {
    banners = await getJSON("data/banners.json");
  } catch {
    return;
  }
  if (!banners.length) return;

  hero.querySelectorAll(".hero-slide").forEach((slide) => slide.remove());
  const slides = banners.map(createSlide);
  slides.forEach((slide) => hero.prepend(slide));
  renderCopy(copyRoot, banners[0]);

  const style = document.createElement("style");
  style.textContent = styles;
  document.head.append(style);
  const progress = document.createElement("div");
  progress.className = "hero-progress";
  progress.style.setProperty("--hero-duration", `${DURATION}ms`);
  progress.style.gridTemplateColumns = `repeat(${slides.length},minmax(0,1fr))`;
  progress.setAttribute("aria-label", `${slides.length} slides no carrossel`);
  hero.insertBefore(progress, hero.querySelector(".hero-controls"));

  let current = 0;
  let timer;
  let progressFrame;
  const bars = slides.map((_, index) => {
    const button = document.createElement("button");
    button.className = "hero-progress-item";
    button.type = "button";
    button.setAttribute(
      "aria-label",
      `Ir para o slide ${index + 1} de ${slides.length}`,
    );
    button.append(document.createElement("span"));
    button.addEventListener("click", () => show(index));
    progress.append(button);
    return button;
  });
  const animate = () => {
    cancelAnimationFrame(progressFrame);
    bars.forEach((bar, index) => {
      const fill = bar.querySelector("span");
      bar.classList.remove("is-complete", "is-running");
      bar.removeAttribute("aria-current");
      fill.style.transform = `scaleX(${index < current ? 1 : 0})`;
    });
    const activeFill = bars[current].querySelector("span");
    bars[current].setAttribute("aria-current", "true");
    const startedAt = performance.now();
    const updateProgress = (now) => {
      const value = Math.min((now - startedAt) / DURATION, 1);
      activeFill.style.transform = `scaleX(${value})`;
      if (value < 1) progressFrame = requestAnimationFrame(updateProgress);
    };
    progressFrame = requestAnimationFrame(updateProgress);
  };
  const schedule = () => {
    clearTimeout(timer);
    timer = setTimeout(() => show(current + 1), DURATION);
  };
  function show(index) {
    slides[current].classList.remove("active");
    current = (index + slides.length) % slides.length;
    slides[current].classList.add("active");
    renderCopy(copyRoot, banners[current]);
    animate();
    schedule();
  }
  hero
    .querySelector("[data-next]")
    ?.addEventListener("click", () => show(current + 1));
  hero
    .querySelector("[data-prev]")
    ?.addEventListener("click", () => show(current - 1));
  animate();
  schedule();
}
