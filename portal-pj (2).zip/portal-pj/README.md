# Portal PJ

Portal institucional estático, responsivo e orientado a dados, construído com HTML5, Bootstrap 5, CSS e JavaScript Vanilla ES Modules. Não há build, Node ou npm.

## Executar

Copie a pasta para `C:\xampp\htdocs\portal-pj\`, inicie o Apache no XAMPP e acesse `http://localhost/portal-pj/`. Não abra via `file://`: componentes e JSON usam `fetch()`.

Para desenvolvimento, qualquer servidor HTTP estático serve (por exemplo, `python -m http.server 8000`).

## Estrutura

- `components/`: header, footer e overlay de busca compartilhados.
- `assets/css/`: tokens e estilos customizados.
- `assets/js/`: módulos de componentes, navegação, busca, carrossel, soluções e documentos.
- `assets/images/`: imagens locais; substitua mantendo os caminhos ou atualize os JSON.
- `data/solutions.json`: adicione soluções e seus benefícios.
- `data/documents.json`: adicione documentos e caminhos em `pdfs/`.
- `data/search-index.json`: itens pesquisáveis.
- `pages/`: páginas internas.

Os PDFs de demonstração não estão incluídos; coloque os arquivos em `pdfs/` com os nomes configurados em `documents.json`. O formulário de contato apenas valida os campos até que uma URL de backend seja configurada.

## Publicação e URLs

A aplicação funciona em `/portal-pj/`. O `.htaccess` inclui uma regra opcional para `/portal-pj/solucoes/capital-giro`; requer `mod_rewrite`. A URL com query string (`pages/solucao.html?id=capital-giro`) funciona independentemente dessa regra.
