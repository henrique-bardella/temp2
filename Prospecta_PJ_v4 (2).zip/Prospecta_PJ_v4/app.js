﻿const API_CNPJ = "https://brasilapi.com.br/api/cnpj/v1/";
const API_CEP = "https://brasilapi.com.br/api/cep/v2/";
const API_LEADS = (() => {
  const origin = window.location.origin;
  const path = window.location.pathname || "";
  if (path.includes("/Prospecta_PJ/")) {
    return `${origin}/Prospecta_PJ/api/leads.php`;
  }
  const host = window.location.hostname || "localhost";
  return `http://${host}/Prospecta_PJ/api/leads.php`;
})();
const AGENCIAS_CSV = "dados/mesu.csv";
const AGENCIAS_XLSX = "dados/mesu.xlsx";
const CEP_CSV = "dados/br_bd_diretorios_brasil_cep.csv";

const form = document.getElementById("cnpj-form");
const inputCnpj = document.getElementById("cnpj");
const btnConsultarCnpj = document.getElementById("btn-consultar-cnpj");
const btnLimpar = document.getElementById("btn-limpar");
const btnConsultarCep = document.getElementById("btn-consultar-cep");

const cnpjAlert = document.getElementById("cnpj-alert");
const empresaStatus = document.getElementById("empresa-status");
const empresaDados = document.getElementById("empresa-dados");
const localizacaoAlert = document.getElementById("localizacao-alert");
const localizacaoDados = document.getElementById("localizacao-dados");
const agenciaAlert = document.getElementById("agencia-alert");
const agenciaResultado = document.getElementById("agencia-resultado");
const top3Dados = document.getElementById("top3-dados");
const kmRange = document.getElementById("km-range");
const kmValor = document.getElementById("km-valor");
const leadsTbody = document.getElementById("leads-tbody");
const leadsTotal = document.getElementById("leads-total");
const cardLeads = document.getElementById("card-leads");
const btnExportarLeads = document.getElementById("btn-exportar-leads");
const btnExportarLeadsXlsx = document.getElementById("btn-exportar-leads-xlsx");
const btnEnviarEmailSelecionados = document.getElementById("btn-enviar-email-selecionados");
const btnExcluirSelecionados = document.getElementById("btn-excluir-selecionados");
const leadsSelectAll = document.getElementById("leads-select-all");
const leadModalEl = document.getElementById("lead-modal");
const leadModalTitle = document.getElementById("lead-modal-title");
const leadForm = document.getElementById("lead-form");
const leadSalvar = document.getElementById("lead-salvar");
const stepBadge = document.getElementById("step-badge");
const stepProgressBar = document.getElementById("step-progress-bar");
const step1 = document.getElementById("step-1");
const step2 = document.getElementById("step-2");
const step3 = document.getElementById("step-3");
const lastLeadSummary = document.getElementById("last-lead-summary");
const agenciaManualModalEl = document.getElementById("agencia-manual-modal");
const agenciaManualSearch = document.getElementById("agencia-manual-search");
const agenciaManualList = document.getElementById("agencia-manual-list");
const agenciaManualEmpty = document.getElementById("agencia-manual-empty");
const leadEscritorio = document.getElementById("lead-escritorio");
const leadCodAgencia = document.getElementById("lead-cod-agencia");
const leadCodFuncional = document.getElementById("lead-cod-funcional");
const leadNome = document.getElementById("lead-nome");
const leadEmail = document.getElementById("lead-email");
const leadBanco = document.getElementById("lead-banco");
const leadBancoOutro = document.getElementById("lead-banco-outro");
const leadFaturamento = document.getElementById("lead-faturamento");
const leadGrupoEconomico = document.getElementById("lead-grupo-economico");
const leadComentario = document.getElementById("lead-comentario");
const leadRecebedorCodFuncional = document.getElementById("lead-recebedor-cod-funcional");
const leadRecebedorNome = document.getElementById("lead-recebedor-nome");
const leadRecebedorEmail = document.getElementById("lead-recebedor-email");
const cardEmpresa = document.getElementById("card-empresa");
const cardLocalizacao = document.getElementById("card-localizacao");
const cardAgencia = document.getElementById("card-agencia");
const cardTop3 = document.getElementById("card-top3");

let empresaCache = null;
let localizacaoCache = null;
let agenciasCache = [];
let cepBaseCache = null;
let resultadosCache = [];
let leadsCache = [];
let leadAgenciaPendente = null;
let leadEmEdicao = null;
let leadModalInstance = null;
let agenciaManualModalInstance = null;

inputCnpj.addEventListener("input", (event) => {
  event.target.value = aplicarMascaraCnpj(event.target.value);
});

form.addEventListener("submit", (event) => {
  event.preventDefault();
  consultarCNPJ();
});

btnLimpar.addEventListener("click", () => {
  resetarTela();
});

btnConsultarCep.addEventListener("click", () => {
  consultarCEP();
});

if (kmRange) {
  kmRange.addEventListener("input", () => {
    atualizarFiltroKm();
  });
}

if (btnExportarLeads) {
  btnExportarLeads.addEventListener("click", () => {
    exportarLeadsCsv();
  });
}
if (btnExportarLeadsXlsx) {
  btnExportarLeadsXlsx.addEventListener("click", () => {
    exportarLeadsXlsx();
  });
}
if (btnEnviarEmailSelecionados) {
  btnEnviarEmailSelecionados.addEventListener("click", () => {
    enviarEmailSelecionados();
  });
}

if (btnExcluirSelecionados) {
  btnExcluirSelecionados.addEventListener("click", () => {
    removerSelecionados();
  });
}

if (leadsSelectAll) {
  leadsSelectAll.addEventListener("change", () => {
    const marcado = leadsSelectAll.checked;
    leadsCache = leadsCache.map((lead) => ({ ...lead, selecionado: marcado }));
    renderLeads();
  });
}

if (leadModalEl && window.bootstrap) {
  leadModalInstance = new bootstrap.Modal(leadModalEl);
}

if (agenciaManualModalEl && window.bootstrap) {
  agenciaManualModalInstance = new bootstrap.Modal(agenciaManualModalEl);
}

if (leadSalvar) {
  leadSalvar.addEventListener("click", () => {
    salvarLeadComFormulario();
  });
}

configurarSomenteNumeros(leadEscritorio);
configurarSomenteNumeros(leadCodAgencia);
configurarSomenteNumeros(leadCodFuncional);
configurarSomenteNumeros(leadGrupoEconomico);

if (leadBanco) {
  leadBanco.addEventListener("change", () => {
    atualizarBancoOutroVisivel();
  });
  leadBanco.addEventListener("input", () => {
    atualizarBancoOutroVisivel();
  });
}

if (agenciaManualSearch) {
  agenciaManualSearch.addEventListener("input", () => {
    renderAgenciaManualLista(agenciaManualSearch.value);
  });
}

function setLoadingState(container, ativo) {
  if (ativo) {
    container.classList.add("loading-block");
    container.innerHTML = criarSkeleton();
  } else {
    container.classList.remove("loading-block");
    container.classList.add("fade-in");
    setTimeout(() => container.classList.remove("fade-in"), 400);
  }
}

function criarSkeleton() {
  return `
    <div class="skeleton">
      <div class="skeleton-line w-80"></div>
      <div class="skeleton-line w-60"></div>
      <div class="skeleton-line w-40"></div>
      <div class="skeleton-line w-80"></div>
    </div>
  `;
}

function mostrarCard(card) {
  if (!card) return;
  card.classList.remove("d-none");
  card.classList.add("fade-in");
  setTimeout(() => card.classList.remove("fade-in"), 400);
}

function ocultarCard(card) {
  if (!card) return;
  card.classList.add("d-none");
}

function aplicarMascaraCnpj(valor) {
  const digits = valor.replace(/\D/g, "").slice(0, 14);
  return digits
    .replace(/(\d{2})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1/$2")
    .replace(/(\d{4})(\d{1,2})$/, "$1-$2");
}

function formatarCnpj(valor) {
  const digits = String(valor || "").replace(/\D/g, "");
  if (digits.length !== 14) return valor || "-";
  return aplicarMascaraCnpj(digits);
}

function limparCnpj(valor) {
  return valor.replace(/\D/g, "");
}

function aplicarMascaraCep(valor) {
  const digits = String(valor || "").replace(/\D/g, "").slice(0, 8);
  return digits.replace(/(\d{5})(\d{1,3})$/, "$1-$2");
}

function limparCep(valor) {
  return String(valor || "").replace(/\D/g, "");
}

function exibirAlert(container, tipo, mensagem) {
  container.classList.remove("d-none", "alert-success", "alert-danger", "alert-warning", "alert-info");
  container.classList.add(`alert-${tipo}`);
  container.textContent = mensagem;
}

function limparAlert(container) {
  container.classList.add("d-none");
  container.textContent = "";
}

function toggleLoading(botao, ativo) {
  const label = botao.querySelector(".btn-label");
  const spinner = botao.querySelector(".spinner-border");
  if (ativo) {
    botao.setAttribute("disabled", "disabled");
    label.classList.add("d-none");
    spinner.classList.remove("d-none");
  } else {
    botao.removeAttribute("disabled");
    label.classList.remove("d-none");
    spinner.classList.add("d-none");
  }
}

function resetarTela() {
  form.reset();
  empresaCache = null;
  localizacaoCache = null;
  agenciasCache = [];
  resultadosCache = [];
  leadsCache = [];
  empresaStatus.innerHTML = "";
  empresaDados.innerHTML = '<p class="text-muted">Nenhuma consulta realizada ainda.</p>';
  localizacaoDados.innerHTML = '<p class="text-muted">Aguardando consulta de CEP.</p>';
  agenciaResultado.innerHTML = '<p class="text-muted">Consulte o CEP para identificar a agência mais próxima.</p>';
  top3Dados.innerHTML = '<p class="text-muted">Disponível após cálculo de distância.</p>';
  if (lastLeadSummary) {
    lastLeadSummary.classList.add("d-none");
    lastLeadSummary.textContent = "";
  }
  setStep(1);
  if (kmRange) {
    kmRange.value = "10";
  }
  if (kmValor) {
    kmValor.textContent = "Até 10 km";
  }
  if (leadsTotal) {
    leadsTotal.textContent = "0 leads";
  }
  if (leadsTbody) {
    leadsTbody.innerHTML = '<tr><td colspan="22" class="text-muted">Nenhum lead adicionado.</td></tr>';
  }
  if (leadsSelectAll) {
    leadsSelectAll.checked = false;
  }
  btnConsultarCep.setAttribute("disabled", "disabled");
  limparAlert(cnpjAlert);
  limparAlert(localizacaoAlert);
  limparAlert(agenciaAlert);
  ocultarCard(cardEmpresa);
  ocultarCard(cardLocalizacao);
  ocultarCard(cardAgencia);
  ocultarCard(cardTop3);
}

async function consultarCNPJ() {
  limparAlert(cnpjAlert);
  limparAlert(localizacaoAlert);
  limparAlert(agenciaAlert);
  empresaStatus.innerHTML = "";
  const cnpj = limparCnpj(inputCnpj.value);

  if (cnpj.length !== 14) {
    exibirAlert(cnpjAlert, "warning", "CNPJ inválido. Informe 14 dígitos.");
    return;
  }

  toggleLoading(btnConsultarCnpj, true);
  exibirAlert(cnpjAlert, "info", "Verificando se o CNPJ já foi indicado...");
  setLoadingState(empresaDados, true);

  try {
    const validacao = await verificarCnpjCadastrado(cnpj);
    if (validacao && validacao.ok && validacao.exists === true) {
      empresaCache = null;
      empresaStatus.innerHTML = "";
      empresaDados.innerHTML = '<p class="text-muted">Este CNPJ já foi indicado como possível lead.</p>';
      exibirAlert(cnpjAlert, "warning", "CNPJ já foi indicado como possível lead.");
      btnConsultarCep.setAttribute("disabled", "disabled");
      return;
    }
    if (!validacao || !validacao.ok) {
      empresaCache = null;
      empresaStatus.innerHTML = "";
      empresaDados.innerHTML = '<p class="text-muted">Não foi possível validar o CNPJ na base de indicações.</p>';
      exibirAlert(
        cnpjAlert,
        "danger",
        `Não foi possível validar o CNPJ no banco. ${validacao?.error || ""} Verifique se o XAMPP (Apache + MySQL) está ativo e se ${API_LEADS} responde.`
      );
      btnConsultarCep.setAttribute("disabled", "disabled");
      return;
    }

    exibirAlert(cnpjAlert, "info", "Consultando CNPJ...");
    const data = await fetchWithTimeout(`${API_CNPJ}${cnpj}`, 12000);
    empresaCache = normalizarEmpresa(data);
    renderEmpresa(empresaCache);
    exibirAlert(cnpjAlert, "success", "Empresa encontrada.");
    mostrarCard(cardLocalizacao);
    setStep(1);
    btnConsultarCep.removeAttribute("disabled");
  } catch (error) {
    const mensagem = interpretarErro(error, "CNPJ");
    exibirAlert(cnpjAlert, "danger", mensagem);
    empresaCache = null;
    empresaStatus.innerHTML = "";
    renderEmpresaManualErro(mensagem, cnpj);
    btnConsultarCep.setAttribute("disabled", "disabled");
  } finally {
    mostrarCard(cardEmpresa);
    setLoadingState(empresaDados, false);
    toggleLoading(btnConsultarCnpj, false);
  }
}

async function consultarCEP() {
  limparAlert(localizacaoAlert);
  limparAlert(agenciaAlert);

  if (!empresaCache) {
    exibirAlert(localizacaoAlert, "warning", "Consulte um CNPJ antes de buscar o CEP.");
    return;
  }

  const cepLimpo = (empresaCache.cep || "").replace(/\D/g, "");
  if (cepLimpo.length !== 8) {
    exibirAlert(localizacaoAlert, "warning", "CEP inválido ou ausente na base da empresa.");
    return;
  }

  toggleLoading(btnConsultarCep, true);
  exibirAlert(localizacaoAlert, "info", "Consultando CEP...");
  setLoadingState(localizacaoDados, true);
  setLoadingState(agenciaResultado, true);
  setLoadingState(top3Dados, true);

  try {
    const data = await fetchWithTimeout(`${API_CEP}${cepLimpo}`, 12000);
    localizacaoCache = normalizarCep(data);

    if (!localizacaoCache.latitude || !localizacaoCache.longitude) {
      const fallback = await buscarCoordenadasCsv(cepLimpo);
      if (fallback) {
        localizacaoCache = { ...localizacaoCache, ...fallback };
      }
    }

    if (!localizacaoCache.latitude || !localizacaoCache.longitude) {
      exibirAlert(localizacaoAlert, "warning", "CEP sem coordenadas disponíveis.");
      localizacaoDados.innerHTML = '<p class="text-muted">CEP localizado, mas sem coordenadas.</p>';
      await abrirModalAgenciaManual();
      return;
    }

    renderLocalizacao(localizacaoCache);
    exibirAlert(localizacaoAlert, "success", "Localização encontrada.");
    setStep(2);

    if (agenciasCache.length === 0) {
      agenciasCache = await carregarAgencias();
    }

    if (!agenciasCache || agenciasCache.length === 0) {
      exibirAlert(
        agenciaAlert,
        "warning",
        "Base de agências vazia ou não encontrada. Verifique dados/mesu.xlsx ou dados/mesu.csv."
      );
      agenciaResultado.innerHTML = '<p class="text-muted">Não foi possível calcular a agência mais próxima.</p>';
      top3Dados.innerHTML = '<p class="text-muted">Sem agências para exibir.</p>';
      return;
    }

    const resultado = calcularDistancias(localizacaoCache, agenciasCache);
    renderResultado(resultado);
    exibirAlert(agenciaAlert, "success", "Agência encontrada.");
  } catch (error) {
    const fallback = await buscarCoordenadasCsv(cepLimpo);
    if (fallback) {
      localizacaoCache = fallback;
      renderLocalizacao(localizacaoCache);
      exibirAlert(localizacaoAlert, "success", "Localização encontrada via base local.");
      setStep(2);
      if (agenciasCache.length === 0) {
        agenciasCache = await carregarAgencias();
      }
      if (!agenciasCache || agenciasCache.length === 0) {
        exibirAlert(
          agenciaAlert,
          "warning",
          "Base de agências vazia ou não encontrada. Verifique dados/mesu.xlsx ou dados/mesu.csv."
        );
        agenciaResultado.innerHTML = '<p class="text-muted">Não foi possível calcular a agência mais próxima.</p>';
        top3Dados.innerHTML = '<p class="text-muted">Sem agências para exibir.</p>';
        return;
      }
      const resultado = calcularDistancias(localizacaoCache, agenciasCache);
      renderResultado(resultado);
      exibirAlert(agenciaAlert, "success", "Agência encontrada.");
    } else {
      const mensagem = interpretarErro(error, "CEP");
      exibirAlert(localizacaoAlert, "danger", mensagem);
      await abrirModalAgenciaManual();
    }
  } finally {
    mostrarCard(cardLocalizacao);
    mostrarCard(cardAgencia);
    mostrarCard(cardTop3);
    mostrarCard(cardLeads);
    setLoadingState(localizacaoDados, false);
    setLoadingState(agenciaResultado, false);
    setLoadingState(top3Dados, false);
    toggleLoading(btnConsultarCep, false);
  }
}
function normalizarEmpresa(data) {
  return {
    cnpj: data.cnpj || "-",
    razao_social: data.razao_social || "-",
    nome_fantasia: data.nome_fantasia || "-",
    situacao_cadastral: data.descricao_situacao_cadastral || "-",
    data_inicio_atividade: data.data_inicio_atividade || "-",
    porte: data.porte || "-",
    capital_social: data.capital_social ? formatarMoeda(data.capital_social) : "-",
    cnae: data.cnae_fiscal || "-",
    cnae_descricao: data.cnae_fiscal_descricao || "-",
    natureza_juridica: data.natureza_juridica || "-",
    email: data.email || "-",
    telefone: data.ddd_telefone_1 || data.telefone || "-",
    socios: Array.isArray(data.qsa) ? data.qsa.map((item) => item.nome_socio).filter(Boolean).join(", ") : "-",
    tipo_logradouro: data.descricao_tipo_de_logradouro || data.descricao_tipo_logradouro || "-",
    logradouro: data.logradouro || "-",
    numero: data.numero || "-",
    complemento: data.complemento || "-",
    bairro: data.bairro || "-",
    municipio: data.municipio || "-",
    uf: data.uf || "-",
    cep: data.cep || "-",
  };
}

function normalizarCep(data) {
  const coords = extrairCoordenadas(data);
  return {
    cep: data.cep || "-",
    cidade: data.city || data.cidade || "-",
    estado: data.state || data.estado || "-",
    rua: data.street || data.logradouro || "-",
    bairro: data.neighborhood || data.bairro || "-",
    latitude: coords.latitude,
    longitude: coords.longitude,
  };
}

function extrairCoordenadas(data) {
  if (!data) return { latitude: null, longitude: null };

  const rawLocation = data.location && data.location.coordinates ? data.location.coordinates : null;
  let latitude = null;
  let longitude = null;

  if (Array.isArray(rawLocation) && rawLocation.length >= 2) {
    // GeoJSON padrão: [longitude, latitude]
    longitude = rawLocation[0];
    latitude = rawLocation[1];
  } else if (rawLocation && typeof rawLocation === "object") {
    latitude = rawLocation.latitude ?? rawLocation.lat ?? null;
    longitude = rawLocation.longitude ?? rawLocation.lng ?? null;
  } else {
    latitude = data.latitude ?? data.lat ?? null;
    longitude = data.longitude ?? data.lng ?? null;
  }

  return {
    latitude: normalizarNumero(latitude),
    longitude: normalizarNumero(longitude),
  };
}

function normalizarNumero(valor) {
  if (valor === null || valor === undefined || valor === "") return null;
  const numero = parseFloat(String(valor).replace(",", "."));
  return Number.isNaN(numero) ? null : numero;
}

function renderEmpresa(empresa) {
  empresaStatus.innerHTML = `
    <span class="badge badge-status">Situação: ${empresa.situacao_cadastral}</span>
    <span class="badge bg-light text-dark border">Porte: ${empresa.porte}</span>
  `;

  empresaDados.innerHTML = criarListaDados([
    ["CNPJ", empresa.cnpj],
    ["Razão social", empresa.razao_social],
    ["Nome fantasia", empresa.nome_fantasia],
    ["Data início atividade", empresa.data_inicio_atividade],
    ["Capital social", empresa.capital_social],
    ["CNAE", empresa.cnae],
    ["Descrição CNAE", empresa.cnae_descricao],
    ["Natureza jurídica", empresa.natureza_juridica],
    ["Email", empresa.email],
    ["Telefone", empresa.telefone],
    ["Sócios", empresa.socios],
    ["Tipo de logradouro", empresa.tipo_logradouro],
    ["Logradouro", empresa.logradouro],
    ["Número", empresa.numero],
    ["Complemento", empresa.complemento],
    ["Bairro", empresa.bairro],
    ["Município", empresa.municipio],
    ["UF", empresa.uf],
    ["CEP", empresa.cep],
  ]);
}

function renderEmpresaManualErro(mensagem, cnpj) {
  empresaDados.innerHTML = `
    <div class="manual-company-form">
      <div class="alert alert-warning mb-3" role="alert">
        ${mensagem} Preencha os dados principais da empresa manualmente para continuar.
      </div>
      <form id="empresa-manual-form" class="row g-3">
        <div class="col-md-6">
          <label for="empresa-manual-cnpj" class="form-label">CNPJ completo</label>
          <input type="text" class="form-control" id="empresa-manual-cnpj" value="${formatarCnpj(cnpj)}" maxlength="18" required>
        </div>
        <div class="col-md-6">
          <label for="empresa-manual-razao" class="form-label">Razão social</label>
          <input type="text" class="form-control" id="empresa-manual-razao" required>
        </div>
        <div class="col-md-6">
          <label for="empresa-manual-capital" class="form-label">Capital social</label>
          <input type="text" class="form-control" id="empresa-manual-capital" placeholder="0,00" required>
        </div>
        <div class="col-md-6">
          <label for="empresa-manual-telefone" class="form-label">Telefone</label>
          <input type="text" class="form-control" id="empresa-manual-telefone" inputmode="tel" required>
        </div>
        <div class="col-md-8">
          <label for="empresa-manual-logradouro" class="form-label">Logradouro</label>
          <input type="text" class="form-control" id="empresa-manual-logradouro" required>
        </div>
        <div class="col-md-4">
          <label for="empresa-manual-numero" class="form-label">Número</label>
          <input type="text" class="form-control" id="empresa-manual-numero" required>
        </div>
        <div class="col-md-5">
          <label for="empresa-manual-bairro" class="form-label">Bairro</label>
          <input type="text" class="form-control" id="empresa-manual-bairro" required>
        </div>
        <div class="col-md-3">
          <label for="empresa-manual-uf" class="form-label">UF</label>
          <input type="text" class="form-control text-uppercase" id="empresa-manual-uf" maxlength="2" required>
        </div>
        <div class="col-md-4">
          <label for="empresa-manual-cep" class="form-label">CEP</label>
          <input type="text" class="form-control" id="empresa-manual-cep" inputmode="numeric" maxlength="9" required>
        </div>
        <div class="col-12 d-grid d-md-flex gap-2">
          <button type="submit" class="btn btn-primary">Usar dados manuais</button>
        </div>
      </form>
    </div>
  `;

  const manualForm = document.getElementById("empresa-manual-form");
  const manualCnpj = document.getElementById("empresa-manual-cnpj");
  const manualUf = document.getElementById("empresa-manual-uf");
  const manualCep = document.getElementById("empresa-manual-cep");

  manualCnpj?.addEventListener("input", (event) => {
    event.target.value = aplicarMascaraCnpj(event.target.value);
  });
  manualUf?.addEventListener("input", (event) => {
    event.target.value = event.target.value.replace(/[^a-z]/gi, "").slice(0, 2).toUpperCase();
  });
  manualCep?.addEventListener("input", (event) => {
    event.target.value = aplicarMascaraCep(event.target.value);
  });
  manualForm?.addEventListener("submit", salvarEmpresaManual);
}

function salvarEmpresaManual(event) {
  event.preventDefault();

  const cnpj = limparCnpj(document.getElementById("empresa-manual-cnpj")?.value || "");
  const razaoSocial = document.getElementById("empresa-manual-razao")?.value?.trim() || "";
  const uf = document.getElementById("empresa-manual-uf")?.value?.trim().toUpperCase() || "";
  const cep = limparCep(document.getElementById("empresa-manual-cep")?.value || "");

  if (cnpj.length !== 14) {
    exibirAlert(cnpjAlert, "warning", "CNPJ inválido. Informe 14 dígitos para continuar.");
    return;
  }
  if (!razaoSocial) {
    exibirAlert(cnpjAlert, "warning", "Informe a razão social para continuar.");
    return;
  }
  if (uf.length !== 2) {
    exibirAlert(cnpjAlert, "warning", "UF inválida. Informe 2 letras para continuar.");
    return;
  }
  if (cep.length !== 8) {
    exibirAlert(cnpjAlert, "warning", "CEP inválido. Informe 8 dígitos para continuar.");
    return;
  }

  empresaCache = {
    cnpj,
    razao_social: razaoSocial,
    nome_fantasia: "-",
    situacao_cadastral: "Informada manualmente",
    data_inicio_atividade: "-",
    porte: "-",
    capital_social: document.getElementById("empresa-manual-capital")?.value?.trim() || "-",
    cnae: "-",
    cnae_descricao: "-",
    natureza_juridica: "-",
    email: "-",
    telefone: document.getElementById("empresa-manual-telefone")?.value?.trim() || "-",
    socios: "-",
    tipo_logradouro: "-",
    logradouro: document.getElementById("empresa-manual-logradouro")?.value?.trim() || "-",
    numero: document.getElementById("empresa-manual-numero")?.value?.trim() || "-",
    complemento: "-",
    bairro: document.getElementById("empresa-manual-bairro")?.value?.trim() || "-",
    municipio: "-",
    uf,
    cep: cep || "-",
  };

  renderEmpresa(empresaCache);
  exibirAlert(cnpjAlert, "success", "Dados manuais da empresa salvos. Você pode continuar para a consulta da agência.");
  mostrarCard(cardLocalizacao);
  setStep(1);
  btnConsultarCep.removeAttribute("disabled");
}

function renderLocalizacao(localizacao) {
  localizacaoDados.innerHTML = criarListaDados([
    ["CEP", localizacao.cep],
    ["Cidade", localizacao.cidade],
    ["Estado", localizacao.estado],
    ["Rua", localizacao.rua],
    ["Bairro", localizacao.bairro],
    ["Latitude", localizacao.latitude ?? "-"],
    ["Longitude", localizacao.longitude ?? "-"],
  ]);
}

function renderResultado(resultado) {
  if (!resultado || resultado.length === 0) {
    agenciaResultado.innerHTML = '<p class="text-muted">Nenhuma agência válida encontrada.</p>';
    top3Dados.innerHTML = '<p class="text-muted">Sem agências para exibir.</p>';
    resultadosCache = [];
    return;
  }

  const [primeira] = resultado;
  resultadosCache = resultado;
  atualizarLimiteSliderKm();
  const mapaUrl = criarUrlMapa(
    localizacaoCache?.latitude,
    localizacaoCache?.longitude,
    primeira.latitude,
    primeira.longitude
  );
  const lista = criarListaDados([
    ["Código", primeira.codigo_agencia],
    ["Nome", primeira.nome_agencia],
    ["Endereço", primeira.endereco],
    ["Município/UF", `${primeira.municipio} / ${primeira.uf}`],
    ["Distância", `${primeira.distancia_km.toFixed(2)} km`],
  ]);
  const payload = encodeURIComponent(
    JSON.stringify({
      codigo_agencia: primeira.codigo_agencia,
      nome_agencia: primeira.nome_agencia,
      municipio: primeira.municipio,
      uf: primeira.uf,
      email_agencia: primeira.email_agencia || "",
      email_regional: primeira.email_regional || "",
      distancia_km: primeira.distancia_km,
    })
  );

  agenciaResultado.innerHTML = `
    <div class="card-agencia highlight-card">
      <div class="highlight-title mb-2">Agência mais próxima</div>
      ${lista}
      ${
        mapaUrl
          ? `<a class="btn btn-primary map-button" href="${mapaUrl}" target="_blank" rel="noopener noreferrer">Visualizar no mapa</a>`
          : ""
      }
      <button class="btn btn-outline-primary map-button" data-lead-add="true" data-agencia="${payload}">Adicionar lead</button>
    </div>
  `;

  const addBtn = agenciaResultado.querySelector('[data-lead-add="true"]');
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      const raw = addBtn.getAttribute("data-agencia");
      if (!raw) return;
      const agencia = JSON.parse(decodeURIComponent(raw));
      abrirModalLead(agencia);
    });
  }

  atualizarFiltroKm();
  setStep(2);
}

async function abrirModalAgenciaManual() {
  if (!agenciaManualModalInstance || !agenciaManualList) {
    exibirAlert(
      agenciaAlert,
      "warning",
      "Não foi possível abrir a seleção manual. Verifique o modal no HTML."
    );
    return;
  }

  if (agenciasCache.length === 0) {
    agenciasCache = await carregarAgencias();
  }

  if (!agenciasCache || agenciasCache.length === 0) {
    exibirAlert(
      agenciaAlert,
      "warning",
      "Base de agências vazia ou não encontrada. Verifique dados/mesu.xlsx ou dados/mesu.csv."
    );
    agenciaResultado.innerHTML = '<p class="text-muted">Não foi possível selecionar a agência.</p>';
    top3Dados.innerHTML = '<p class="text-muted">Sem agências para exibir.</p>';
    return;
  }

  renderAgenciaManualLista(agenciaManualSearch?.value || "");
  agenciaManualModalInstance.show();
}

function renderAgenciaManualLista(termo) {
  if (!agenciaManualList) return;
  const filtro = String(termo || "").trim().toLowerCase();
  const filtradas = agenciasCache.filter((agencia) => {
    const alvo = [
      agencia.codigo_agencia,
      agencia.nome_agencia,
      agencia.municipio,
      agencia.uf,
    ]
      .join(" ")
      .toLowerCase();
    return !filtro || alvo.includes(filtro);
  });

  if (agenciaManualEmpty) {
    agenciaManualEmpty.classList.toggle("d-none", filtradas.length > 0);
  }

  agenciaManualList.innerHTML = filtradas
    .map((agencia) => {
      const payload = encodeURIComponent(
        JSON.stringify({
          codigo_agencia: agencia.codigo_agencia,
          nome_agencia: agencia.nome_agencia,
          endereco: agencia.endereco,
          municipio: agencia.municipio,
          uf: agencia.uf,
          email_agencia: agencia.email_agencia || "",
          email_regional: agencia.email_regional || "",
          latitude: agencia.latitude,
          longitude: agencia.longitude,
        })
      );
      return `
        <button type="button" class="list-group-item list-group-item-action" data-agencia="${payload}">
          <div class="fw-semibold">${agencia.nome_agencia}</div>
          <div class="text-muted small">${agencia.codigo_agencia} • ${agencia.municipio} / ${agencia.uf}</div>
        </button>
      `;
    })
    .join("");

  agenciaManualList.querySelectorAll("[data-agencia]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const raw = btn.getAttribute("data-agencia");
      if (!raw) return;
      const agencia = JSON.parse(decodeURIComponent(raw));
      agencia.distancia_km = 0;
      agencia._manual = true;
      agenciaManualModalInstance.hide();
      renderAgenciaManual(agencia);
    });
  });
}

function renderAgenciaManual(agencia) {
  const mapaUrl = criarUrlMapa(
    localizacaoCache?.latitude,
    localizacaoCache?.longitude,
    agencia.latitude,
    agencia.longitude
  );
  resultadosCache = [agencia];
  const lista = criarListaDados([
    ["Código", agencia.codigo_agencia],
    ["Nome", agencia.nome_agencia],
    ["Endereço", agencia.endereco],
    ["Município/UF", `${agencia.municipio} / ${agencia.uf}`],
    ["Distância", "Selecionada manualmente"],
  ]);
  const payload = encodeURIComponent(
    JSON.stringify({
      codigo_agencia: agencia.codigo_agencia,
      nome_agencia: agencia.nome_agencia,
      municipio: agencia.municipio,
      uf: agencia.uf,
      email_agencia: agencia.email_agencia || "",
      email_regional: agencia.email_regional || "",
      distancia_km: agencia.distancia_km,
    })
  );

  agenciaResultado.innerHTML = `
    <div class="card-agencia highlight-card">
      <div class="highlight-title mb-2">Agência selecionada manualmente</div>
      ${lista}
      ${
        mapaUrl
          ? `<a class="btn btn-primary map-button" href="${mapaUrl}" target="_blank" rel="noopener noreferrer">Visualizar no mapa</a>`
          : ""
      }
      <button class="btn btn-outline-primary map-button" data-lead-add="true" data-agencia="${payload}">Adicionar lead</button>
    </div>
  `;

  const addBtn = agenciaResultado.querySelector('[data-lead-add="true"]');
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      const raw = addBtn.getAttribute("data-agencia");
      if (!raw) return;
      const agenciaSelecionada = JSON.parse(decodeURIComponent(raw));
      abrirModalLead(agenciaSelecionada);
    });
  }

  top3Dados.innerHTML = '<p class="text-muted">Seleção manual ativa. Filtro por distância indisponível.</p>';
  exibirAlert(agenciaAlert, "info", "Agência selecionada manualmente.");
}

function atualizarFiltroKm() {
  if (!kmRange || !kmValor) return;
  const limite = Number(kmRange.value);
  kmValor.textContent = `Até ${limite} km`;

  if (!resultadosCache || resultadosCache.length === 0) {
    top3Dados.innerHTML = '<p class="text-muted">Sem agências para exibir.</p>';
    return;
  }

  const filtradas = resultadosCache.filter((agencia) => agencia.distancia_km <= limite);
  if (filtradas.length === 0) {
    top3Dados.innerHTML = '<p class="text-muted">Nenhuma agência dentro do raio selecionado.</p>';
    return;
  }

  top3Dados.innerHTML = filtradas
    .map(
      (agencia) => `
        <div class="col-md-4">
          <div class="card-agencia h-100">
            <div class="d-flex justify-content-between align-items-start">
              <div>
                <div class="fw-semibold">${agencia.nome_agencia}</div>
                <div class="text-muted small">${agencia.codigo_agencia}</div>
              </div>
              <span class="badge bg-light text-dark border">${agencia.distancia_km.toFixed(2)} km</span>
            </div>
            <div class="mt-2 text-muted small">${agencia.endereco}</div>
            <div class="text-muted small">${agencia.municipio} / ${agencia.uf}</div>
            ${
              criarUrlMapa(
                localizacaoCache?.latitude,
                localizacaoCache?.longitude,
                agencia.latitude,
                agencia.longitude
              )
                ? `<a class="btn btn-outline-primary btn-sm map-button" href="${criarUrlMapa(
                    localizacaoCache?.latitude,
                    localizacaoCache?.longitude,
                    agencia.latitude,
                    agencia.longitude
                  )}" target="_blank" rel="noopener noreferrer">Visualizar no mapa</a>`
                : ""
            }
            <button class="btn btn-primary btn-sm map-button" data-lead-add="true" data-agencia="${encodeURIComponent(
              JSON.stringify({
                codigo_agencia: agencia.codigo_agencia,
                nome_agencia: agencia.nome_agencia,
                municipio: agencia.municipio,
                uf: agencia.uf,
                email_agencia: agencia.email_agencia || "",
                email_regional: agencia.email_regional || "",
                distancia_km: agencia.distancia_km,
              })
            )}">Adicionar lead</button>
          </div>
        </div>
      `
    )
    .join("");

  if (top3Dados) {
    top3Dados.querySelectorAll("[data-lead-add=\"true\"]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const payload = btn.getAttribute("data-agencia");
        if (!payload) return;
        const agencia = JSON.parse(decodeURIComponent(payload));
        abrirModalLead(agencia);
      });
    });
  }
}

function criarListaDados(itens) {
  return itens
    .filter((item) => item[1] && item[1] !== "-")
    .map(
      ([label, valor]) => `
        <div class="data-item">
          <div class="data-label">${label}</div>
          <div class="data-value">${valor}</div>
        </div>
      `
    )
    .join("") || '<p class="text-muted">Nenhuma informação disponível.</p>';
}

async function carregarAgencias() {
  let agencias = await carregarXLSX();
  if (agencias.length > 0) {
    return agencias;
  }
  agencias = await carregarCSV();
  return agencias;
}

function criarUrlMapa(origLat, origLon, destLat, destLon) {
  const oLat = normalizarNumero(origLat);
  const oLon = normalizarNumero(origLon);
  const dLat = normalizarNumero(destLat);
  const dLon = normalizarNumero(destLon);
  if (dLat === null || dLon === null) return "";
  if (oLat !== null && oLon !== null) {
    return `https://www.google.com/maps/dir/?api=1&origin=${oLat},${oLon}&destination=${dLat},${dLon}&travelmode=driving`;
  }
  return `https://www.google.com/maps/search/?api=1&query=${dLat},${dLon}`;
}

function adicionarLead(agencia, faturamentoAnual) {
  if (!empresaCache) return;
  const chave = `${empresaCache.cnpj}-${agencia.codigo_agencia}`;
  const jaExiste = leadsCache.some((lead) => lead.chave === chave);
  if (jaExiste) {
    exibirAlert(agenciaAlert, "warning", "Lead já adicionado para esta empresa e agência.");
    return;
  }
  const lead = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    chave,
    empresa: empresaCache.nome_fantasia !== "-" ? empresaCache.nome_fantasia : empresaCache.razao_social,
    cnpj: empresaCache.cnpj,
    telefone: empresaCache.telefone || "-",
    endereco: formatarEnderecoEmpresa(empresaCache),
    cliente_municipio: empresaCache.municipio || "-",
    cliente_uf: empresaCache.uf || "-",
    cliente_cep: empresaCache.cep || "-",
    escritorio: leadEscritorio?.value?.trim() || "-",
    codigo_agencia_input: leadCodAgencia?.value?.trim() || "-",
    codigo_funcional: leadCodFuncional?.value?.trim() || "-",
    nome_completo: leadNome?.value?.trim() || "-",
    email: leadEmail?.value?.trim() || "-",
    recebedor_codigo_funcional: leadRecebedorCodFuncional?.value?.trim() || null,
    recebedor_nome_completo: leadRecebedorNome?.value?.trim() || null,
    recebedor_email: leadRecebedorEmail?.value?.trim() || null,
    email_agencia: agencia.email_agencia || "-",
    email_regional: agencia.email_regional || null,
    banco_atual: obterBancoAtual(),
    grupo_economico: leadGrupoEconomico?.value?.trim() || "-",
    faturamento_anual: faturamentoAnual,
    comentario: leadComentario?.value?.trim() || "-",
    codigo_agencia: agencia.codigo_agencia,
    nome_agencia: agencia.nome_agencia,
    municipio: agencia.municipio,
    uf: agencia.uf,
    distancia_km: agencia.distancia_km,
    selecionado: false,
  };
  leadsCache.push(lead);
  renderLeads();
}

function atualizarLimiteSliderKm() {
  if (!kmRange || !resultadosCache || resultadosCache.length === 0) return;
  const maiorDistancia = Math.max(...resultadosCache.map((agencia) => Number(agencia.distancia_km) || 0));
  kmRange.max = String(Math.max(10, Math.ceil(maiorDistancia)));
}

function renderLeads() {
  if (!leadsTbody || !leadsTotal) return;
  leadsTotal.textContent = `${leadsCache.length} lead${leadsCache.length === 1 ? "" : "s"}`;
  if (leadsCache.length === 0) {
    if (leadsSelectAll) leadsSelectAll.checked = false;
    leadsTbody.innerHTML = '<tr><td colspan="22" class="text-muted">Nenhum lead adicionado.</td></tr>';
    return;
  }
  leadsTbody.innerHTML = leadsCache
    .map(
      (lead) => `
      <tr>
        <td>
          <input type="checkbox" data-lead-check="${lead.id}" ${lead.selecionado ? "checked" : ""} />
        </td>
        <td>
          <div class="d-flex gap-2 flex-wrap">
            <button class="btn btn-outline-secondary btn-sm" data-lead-edit="${lead.id}">Editar</button>
            <button class="btn btn-outline-primary btn-sm" data-lead-email="${lead.id}">Enviar email</button>
            <button class="btn btn-outline-danger btn-sm" data-lead-delete="${lead.id}">Excluir</button>
          </div>
        </td>
        <td>${formatarCnpj(lead.cnpj)}</td>
        <td>${lead.empresa}</td>
        <td>${lead.telefone}</td>
        <td>${lead.endereco}</td>
        <td>${lead.escritorio}</td>
        <td>${lead.codigo_agencia_input}</td>
        <td>${lead.codigo_funcional}</td>
        <td>${lead.nome_completo}</td>
        <td>${lead.email}</td>
        <td>${lead.recebedor_codigo_funcional || "-"}</td>
        <td>${lead.recebedor_nome_completo || "-"}</td>
        <td>${lead.recebedor_email || "-"}</td>
        <td>${lead.email_agencia}</td>
        <td>${lead.banco_atual}</td>
        <td>${lead.grupo_economico}</td>
        <td>${formatarMoeda(lead.faturamento_anual)}</td>
        <td>${lead.comentario}</td>
        <td>${lead.nome_agencia} (${lead.codigo_agencia})</td>
        <td>${lead.municipio} / ${lead.uf}</td>
        <td>${lead.distancia_km.toFixed(2)} km</td>
      </tr>
    `
    )
    .join("");

  if (leadsSelectAll) {
    leadsSelectAll.checked = leadsCache.length > 0 && leadsCache.every((lead) => lead.selecionado);
  }

  leadsTbody.querySelectorAll("[data-lead-check]").forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
      const id = checkbox.getAttribute("data-lead-check");
      leadsCache = leadsCache.map((lead) =>
        lead.id === id ? { ...lead, selecionado: checkbox.checked } : lead
      );
      if (leadsSelectAll) {
        leadsSelectAll.checked = leadsCache.length > 0 && leadsCache.every((lead) => lead.selecionado);
      }
    });
  });

  leadsTbody.querySelectorAll("[data-lead-delete]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-lead-delete");
      if (confirm("Deseja excluir este lead?")) {
        removerLead(id);
      }
    });
  });

  leadsTbody.querySelectorAll("[data-lead-edit]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-lead-edit");
      const lead = leadsCache.find((item) => item.id === id);
      if (lead) {
        abrirModalEdicao(lead);
      }
    });
  });

  leadsTbody.querySelectorAll("[data-lead-email]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-lead-email");
      enviarEmailLead(id);
    });
  });
}

function removerLead(id) {
  leadsCache = leadsCache.filter((lead) => lead.id !== id);
  renderLeads();
}

function removerSelecionados() {
  if (leadsCache.length === 0) return;
  const temSelecionado = leadsCache.some((lead) => lead.selecionado);
  if (!temSelecionado) return;
  if (confirm("Deseja excluir os leads selecionados?")) {
    leadsCache = leadsCache.filter((lead) => !lead.selecionado);
    renderLeads();
  }
}

function resetarConsulta() {
  form.reset();
  empresaCache = null;
  localizacaoCache = null;
  agenciasCache = [];
  resultadosCache = [];
  empresaStatus.innerHTML = "";
  empresaDados.innerHTML = '<p class="text-muted">Nenhuma consulta realizada ainda.</p>';
  localizacaoDados.innerHTML = '<p class="text-muted">Aguardando consulta de CEP.</p>';
  agenciaResultado.innerHTML = '<p class="text-muted">Consulte o CEP para identificar a agência mais próxima.</p>';
  top3Dados.innerHTML = '<p class="text-muted">Disponível após cálculo de distância.</p>';
  setStep(1);
  if (kmRange) kmRange.value = "10";
  if (kmValor) kmValor.textContent = "Até 10 km";
  btnConsultarCep.setAttribute("disabled", "disabled");
  limparAlert(cnpjAlert);
  limparAlert(localizacaoAlert);
  limparAlert(agenciaAlert);
  ocultarCard(cardLocalizacao);
  ocultarCard(cardAgencia);
  ocultarCard(cardTop3);
}

function formatarEnderecoEmpresa(empresa) {
  if (!empresa) return "-";
  const partes = [
    empresa.tipo_logradouro,
    empresa.logradouro,
    empresa.numero,
    empresa.complemento,
    empresa.bairro,
    empresa.municipio,
    empresa.uf,
    empresa.cep,
  ]
    .filter((item) => item && item !== "-")
    .join(", ");
  return partes || "-";
}

function exportarLeadsCsv() {
  if (!leadsCache || leadsCache.length === 0) return;
  const headers = [
    "Empresa",
    "CNPJ",
    "Telefone",
    "Endereco",
    "Escritorio",
    "Agencia_gerente",
    "Codigo_funcional",
    "Nome_completo",
    "Email_gerente",
    "Recebedor_codigo_funcional",
    "Recebedor_nome_completo",
    "Recebedor_email",
    "Email_agencia",
    "Banco_atual",
    "Grupo_economico",
    "Faturamento_anual",
    "Comentario",
    "Agencia",
    "Municipio_UF",
    "Distancia_km",
  ];
  const linhas = leadsCache.map((lead) => [
    lead.empresa,
    lead.cnpj,
    lead.telefone,
    lead.endereco,
    lead.escritorio,
    lead.codigo_agencia_input,
    lead.codigo_funcional,
    lead.nome_completo,
    lead.email,
    lead.recebedor_codigo_funcional,
    lead.recebedor_nome_completo,
    lead.recebedor_email,
    lead.email_agencia,
    lead.banco_atual,
    lead.grupo_economico,
    lead.faturamento_anual,
    lead.comentario,
    `${lead.nome_agencia} (${lead.codigo_agencia})`,
    `${lead.municipio} / ${lead.uf}`,
    lead.distancia_km.toFixed(2),
  ]);
  const csv = [headers, ...linhas]
    .map((linha) => linha.map(escapeCsv).join(";"))
    .join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `leads_${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function escapeCsv(valor) {
  if (valor === null || valor === undefined) return "";
  const str = String(valor);
  if (str.includes(";") || str.includes("\"") || str.includes("\n")) {
    return `"${str.replace(/\"/g, "\"\"")}"`;
  }
  return str;
}

async function enviarEmailLead(id) {
  const lead = leadsCache.find((item) => item.id === id);
  if (!lead) return;
  if (!lead.email_agencia || lead.email_agencia === "-") {
    alert("Email da agência não informado na base.");
    return;
  }

  const validacao = await verificarCnpjCadastrado(lead.cnpj);
  if (validacao && validacao.ok && validacao.exists === true) {
    alert("CNPJ já foi indicado como possível lead.");
    return;
  }
  if (!validacao || !validacao.ok) {
    alert(
      `Não foi possível validar o CNPJ no banco. ${validacao?.error || ""} Verifique se o XAMPP (Apache + MySQL) está ativo e se ${API_LEADS} responde.`
    );
    return;
  }

  const resultado = await salvarLeadNoBackend(lead);
  if (!resultado.ok) {
    if (resultado.status === 409) {
      alert("CNPJ já foi indicado como possível lead.");
      return;
    }
    alert("Não foi possível registrar o lead no banco.");
    return;
  }

  renderResumoLead(lead);
  limparTabelaLeads();
  const subject = encodeURIComponent(`NOVO LEAD | ${lead.empresa}`);
  const body = encodeURIComponent(
    [
      "NOVO LEAD",
      "",
      String(lead.empresa || "").toUpperCase(),
      `CNPJ: ${formatarCnpj(lead.cnpj)}`,
      "",
      "RESUMO",
      `Faturamento anual: ${formatarFaturamentoEmail(lead.faturamento_anual)}`,
      `Banco atual: ${valorEmail(lead.banco_atual)}`,
      `Distância: ${formatarDistanciaEmail(lead.distancia_km)}`,
      "",
      "DADOS DA EMPRESA",
      `Localização: ${formatarMunicipioUfEmail(lead.cliente_municipio, lead.cliente_uf)}`,
      `Endereço: ${valorEmail(lead.endereco)}`,
      `CEP: ${formatarCepEmail(lead.cliente_cep)}`,
      `Grupo econômico: ${valorEmail(lead.grupo_economico)}`,
      `Telefone: ${valorEmail(lead.telefone)}`,
      "",
      "ENCAMINHAMENTO",
      `Agência: ${lead.codigo_agencia} — ${valorEmail(lead.nome_agencia)}`,
      `Responsável: ${valorEmail(lead.recebedor_nome_completo)}`,
      `Código funcional: ${valorEmail(lead.recebedor_codigo_funcional)}`,
      `E-mail: ${valorEmail(lead.recebedor_email)}`,
      "",
      "ORIGEM",
      `Indicado por: ${valorEmail(lead.nome_completo)}`,
      `Código funcional: ${valorEmail(lead.codigo_funcional)}`,
      `Número do escritório: ${valorEmail(lead.escritorio)}`,
      `E-mail: ${valorEmail(lead.email)}`,
      ...(lead.comentario && lead.comentario !== "-"
        ? ["", "COMENTÁRIO ADICIONAL", lead.comentario]
        : []),
    ].join("\n")
  );
  const emailsEmCopia = [lead.email, lead.recebedor_email, lead.email_regional]
    .map((email) => String(email || "").trim())
    .filter((email, indice, lista) => email && email !== "-" && lista.indexOf(email) === indice);
  const cc = emailsEmCopia.length > 0 ? `&cc=${encodeURIComponent(emailsEmCopia.join(","))}` : "";
  window.location.href = `mailto:${encodeURIComponent(lead.email_agencia)}?subject=${subject}&body=${body}${cc}`;
  setTimeout(() => {
    resetarConsulta();
  }, 300);
}

function limparTabelaLeads() {
  leadsCache = [];
  renderLeads();
}

function renderResumoLead(lead) {
  if (!lastLeadSummary || !lead) return;
  lastLeadSummary.innerHTML = `
    <div class="fw-semibold">Lead finalizado</div>
    <div class="small text-muted">
      ${lead.empresa} • ${formatarCnpj(lead.cnpj)} • ${lead.nome_agencia} (${lead.codigo_agencia})
    </div>
  `;
  lastLeadSummary.classList.remove("d-none");
  setStep(3);
}

function setStep(step) {
  const total = 3;
  const clamped = Math.max(1, Math.min(total, Number(step) || 1));
  if (stepBadge) stepBadge.textContent = `Passo ${clamped} de ${total}`;
  if (stepProgressBar) stepProgressBar.style.width = `${(clamped / total) * 100}%`;
  const steps = [step1, step2, step3];
  steps.forEach((el, index) => {
    if (!el) return;
    const pos = index + 1;
    el.classList.toggle("is-active", pos === clamped);
    el.classList.toggle("is-done", pos < clamped);
  });
}

async function enviarEmailSelecionados() {
  if (!leadsCache || leadsCache.length === 0) return;
  const selecionados = leadsCache.filter((lead) => lead.selecionado);
  if (selecionados.length === 0) {
    alert("Selecione um lead para enviar email.");
    return;
  }
  if (selecionados.length > 1) {
    alert("Selecione apenas um lead para enviar email.");
    return;
  }
  await enviarEmailLead(selecionados[0].id);
}

function formatarDataMysql(date) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(
    date.getHours()
  )}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function montarPayloadLead(lead) {
  return {
    cnpj: lead.cnpj,
    empresa: lead.empresa,
    telefone: lead.telefone,
    endereco: lead.endereco,
    escritorio: lead.escritorio,
    agencia_gerente: lead.codigo_agencia_input,
    codigo_funcional: lead.codigo_funcional,
    nome_completo: lead.nome_completo,
    email_gerente: lead.email,
    recebedor_codigo_funcional: normalizarOpcionalParaApi(lead.recebedor_codigo_funcional),
    recebedor_nome_completo: normalizarOpcionalParaApi(lead.recebedor_nome_completo),
    recebedor_email: normalizarOpcionalParaApi(lead.recebedor_email),
    email_agencia: lead.email_agencia,
    banco_atual: lead.banco_atual,
    grupo_economico: lead.grupo_economico,
    faturamento_anual: lead.faturamento_anual,
    comentario: lead.comentario,
    agencia: `${lead.nome_agencia} (${lead.codigo_agencia})`,
    municipio_uf: `${lead.municipio} / ${lead.uf}`,
    distancia_km: lead.distancia_km,
    status: "enviado",
    data_envio: formatarDataMysql(new Date()),
  };
}

function normalizarOpcionalParaApi(valor) {
  const normalizado = String(valor ?? "").trim();
  return normalizado === "" || normalizado === "-" ? null : normalizado;
}

async function salvarLeadNoBackend(lead) {
  try {
    const payload = montarPayloadLead(lead);
    const response = await fetch(API_LEADS, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!response.ok) {
      return { ok: false, status: response.status };
    }
    return { ok: true, status: response.status };
  } catch (error) {
    return { ok: false, status: 0 };
  }
}

async function verificarCnpjCadastrado(cnpj) {
  const cnpjLimpo = String(cnpj || "").replace(/\D/g, "");
  if (cnpjLimpo.length !== 14) return { ok: false, error: "CNPJ inválido." };
  try {
    const response = await fetch(`${API_LEADS}?cnpj=${encodeURIComponent(cnpjLimpo)}`);
    const texto = await response.text();
    if (!response.ok) {
      return { ok: false, error: `API retornou ${response.status}: ${texto.slice(0, 120)}` };
    }
    const limpo = texto.replace(/^\uFEFF/, "").trim();
    let data;
    try {
      data = limpo ? JSON.parse(limpo) : [];
    } catch (parseError) {
      return { ok: false, error: `Resposta inválida da API: ${parseError?.message || "JSON inválido"}` };
    }
    return { ok: true, exists: Array.isArray(data) && data.length > 0 };
  } catch (error) {
    return { ok: false, error: `Erro de rede: ${error?.message || "desconhecido"}.` };
  }
}

function exportarLeadsXlsx() {
  if (!leadsCache || leadsCache.length === 0) return;
  if (!window.XLSX) {
    exibirAlert(agenciaAlert, "warning", "Biblioteca XLSX não disponível para exportação.");
    return;
  }
  const dados = leadsCache.map((lead) => ({
    Empresa: lead.empresa,
    CNPJ: lead.cnpj,
    Telefone: lead.telefone,
    Endereco: lead.endereco,
    Escritorio: lead.escritorio,
    Agencia_gerente: lead.codigo_agencia_input,
    Codigo_funcional: lead.codigo_funcional,
    Nome_completo: lead.nome_completo,
    Email_gerente: lead.email,
    Recebedor_codigo_funcional: lead.recebedor_codigo_funcional,
    Recebedor_nome_completo: lead.recebedor_nome_completo,
    Recebedor_email: lead.recebedor_email,
    Email_agencia: lead.email_agencia,
    Banco_atual: lead.banco_atual,
    Grupo_economico: lead.grupo_economico,
    Faturamento_anual: lead.faturamento_anual,
    Comentario: lead.comentario,
    Agencia: `${lead.nome_agencia} (${lead.codigo_agencia})`,
    Municipio_UF: `${lead.municipio} / ${lead.uf}`,
    Distancia_km: Number(lead.distancia_km.toFixed(2)),
  }));
  const worksheet = XLSX.utils.json_to_sheet(dados);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Leads");
  XLSX.writeFile(workbook, `leads_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

function abrirModalLead(agencia) {
  prepararModalLead("Adicionar lead", "Adicionar lead");
  leadEmEdicao = null;
  leadAgenciaPendente = agencia;
  if (leadForm) leadForm.reset();
  if (leadBanco) leadBanco.value = "";
  if (leadBancoOutro) leadBancoOutro.value = "";
  if (leadGrupoEconomico) leadGrupoEconomico.value = "";
  atualizarBancoOutroVisivel();
  if (leadFaturamento) leadFaturamento.value = "";
  if (leadModalInstance) {
    leadModalInstance.show();
  }
}

function abrirModalEdicao(lead) {
  prepararModalLead("Editar lead", "Salvar alterações");
  leadEmEdicao = lead.id;
  leadAgenciaPendente = null;
  if (leadForm) leadForm.reset();
  if (leadEscritorio) leadEscritorio.value = lead.escritorio !== "-" ? lead.escritorio : "";
  if (leadCodAgencia) leadCodAgencia.value = lead.codigo_agencia_input !== "-" ? lead.codigo_agencia_input : "";
  if (leadCodFuncional) leadCodFuncional.value = lead.codigo_funcional !== "-" ? lead.codigo_funcional : "";
  if (leadNome) leadNome.value = lead.nome_completo !== "-" ? lead.nome_completo : "";
  if (leadEmail) leadEmail.value = lead.email !== "-" ? lead.email : "";
  if (leadRecebedorCodFuncional) leadRecebedorCodFuncional.value = lead.recebedor_codigo_funcional || "";
  if (leadRecebedorNome) leadRecebedorNome.value = lead.recebedor_nome_completo || "";
  if (leadRecebedorEmail) leadRecebedorEmail.value = lead.recebedor_email || "";
  aplicarBancoAtualNoFormulario(lead.banco_atual);
  if (leadFaturamento) {
    leadFaturamento.value = lead.faturamento_anual ? formatarMoeda(lead.faturamento_anual) : "";
  }
  if (leadGrupoEconomico) {
    leadGrupoEconomico.value = lead.grupo_economico !== "-" ? lead.grupo_economico : "";
  }
  if (leadComentario) leadComentario.value = lead.comentario !== "-" ? lead.comentario : "";
  if (leadModalInstance) {
    leadModalInstance.show();
  }
}

function prepararModalLead(titulo, textoBotao) {
  if (leadModalTitle) leadModalTitle.textContent = titulo;
  if (leadSalvar) leadSalvar.textContent = textoBotao;
}

function salvarLeadComFormulario() {
  const emailGerente = leadEmail?.value?.trim() || "";
  const emailRecebedor = leadRecebedorEmail?.value?.trim() || "";
  if (!emailGerente) {
    alert("Informe o email do gerente.");
    return;
  }
  if (!validarEmail(emailGerente)) {
    alert("Email do gerente inválido.");
    return;
  }
  if (emailRecebedor && !validarEmail(emailRecebedor)) {
    alert("Email do recebedor inválido.");
    return;
  }
  const bancoAtual = obterBancoAtual();
  if (leadBanco?.value === "Outro" && bancoAtual === "-") {
    alert("Informe o banco atual do cliente.");
    return;
  }
  const faturamentoTexto = leadFaturamento?.value?.trim() || "";
  if (!faturamentoTexto) {
    alert("Informe o faturamento anual.");
    return;
  }
  const faturamentoValor = parseValorMonetarioBR(faturamentoTexto);
  if (Number.isNaN(faturamentoValor)) {
    alert("Faturamento anual inválido.");
    return;
  }
  if (faturamentoValor <= 4800000) {
    alert("Faturamento anual deve ser maior que R$ 4.800.000.");
    return;
  }
  if (leadEmEdicao) {
    leadsCache = leadsCache.map((lead) =>
      lead.id === leadEmEdicao
        ? {
            ...lead,
            escritorio: leadEscritorio?.value?.trim() || "-",
            codigo_agencia_input: leadCodAgencia?.value?.trim() || "-",
            codigo_funcional: leadCodFuncional?.value?.trim() || "-",
            nome_completo: leadNome?.value?.trim() || "-",
            email: emailGerente,
            recebedor_codigo_funcional: leadRecebedorCodFuncional?.value?.trim() || null,
            recebedor_nome_completo: leadRecebedorNome?.value?.trim() || null,
            recebedor_email: emailRecebedor || null,
            banco_atual: bancoAtual,
            grupo_economico: leadGrupoEconomico?.value?.trim() || "-",
            faturamento_anual: faturamentoValor,
            comentario: leadComentario?.value?.trim() || "-",
          }
        : lead
    );
    renderLeads();
    leadEmEdicao = null;
  } else {
    if (!leadAgenciaPendente) return;
    adicionarLead(leadAgenciaPendente, faturamentoValor);
  }
  leadAgenciaPendente = null;
  if (leadModalInstance) {
    leadModalInstance.hide();
  }
}

function validarEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function configurarSomenteNumeros(elemento) {
  if (!elemento) return;
  elemento.addEventListener("input", () => {
    elemento.value = elemento.value.replace(/\D/g, "");
  });
}

function atualizarBancoOutroVisivel() {
  if (!leadBancoOutro) return;
  const valor = (leadBanco?.value || "").trim().toLowerCase();
  const mostrarOutro = valor === "outro";
  leadBancoOutro.classList.toggle("d-none", !mostrarOutro);
  if (!mostrarOutro) {
    leadBancoOutro.value = "";
  }
}

function obterBancoAtual() {
  if (!leadBanco) return "-";
  const valor = (leadBanco.value || "").trim();
  if (!valor) return "-";
  if (valor.toLowerCase() === "outro") {
    const outro = leadBancoOutro?.value?.trim() || "";
    return outro || "-";
  }
  return valor;
}

function aplicarBancoAtualNoFormulario(valor) {
  if (!leadBanco) return;
  const valorLimpo = valor && valor !== "-" ? valor : "";
  const opcoes = Array.from(leadBanco.options || []).map((option) => option.value);
  if (!valorLimpo) {
    leadBanco.value = "";
    if (leadBancoOutro) leadBancoOutro.value = "";
    atualizarBancoOutroVisivel();
    return;
  }
  if (opcoes.includes(valorLimpo) && valorLimpo.toLowerCase() !== "outro") {
    leadBanco.value = valorLimpo;
    if (leadBancoOutro) leadBancoOutro.value = "";
    atualizarBancoOutroVisivel();
    return;
  }
  leadBanco.value = "Outro";
  if (leadBancoOutro) leadBancoOutro.value = valorLimpo;
  atualizarBancoOutroVisivel();
}

async function carregarCSV() {
  try {
    const response = await fetch(AGENCIAS_CSV);
    if (!response.ok) {
      console.warn("CSV de agências não encontrado:", AGENCIAS_CSV, response.status);
      return [];
    }
    const texto = await response.text();
    return normalizarAgencias(parseCsv(texto));
  } catch (error) {
    return [];
  }
}

async function carregarXLSX() {
  try {
    const response = await fetch(AGENCIAS_XLSX);
    if (!response.ok) {
      console.warn("XLSX de agências não encontrado:", AGENCIAS_XLSX, response.status);
      return [];
    }
    const arrayBuffer = await response.arrayBuffer();
    if (!window.XLSX) {
      throw new Error("XLSX_LIB_MISSING");
    }
    const workbook = XLSX.read(arrayBuffer, { type: "array" });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const json = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
    return normalizarAgencias(json);
  } catch (error) {
    return [];
  }
}

function parseCsv(texto) {
  const linhas = texto.split(/\r?\n/).filter(Boolean);
  if (linhas.length === 0) return [];
  const delimitador = linhas[0].includes(";") ? ";" : ",";
  const headers = parseCsvLine(linhas[0], delimitador).map((item) => item.trim());
  return linhas.slice(1).map((linha) => {
    const valores = parseCsvLine(linha, delimitador);
    const registro = {};
    headers.forEach((header, index) => {
      registro[header] = (valores[index] || "").trim();
    });
    return registro;
  });
}

function parseCsvLine(linha, delimitador) {
  const resultado = [];
  let atual = "";
  let emAspas = false;

  for (let i = 0; i < linha.length; i++) {
    const char = linha[i];
    if (char === "\"") {
      if (emAspas && linha[i + 1] === "\"") {
        atual += "\"";
        i++;
      } else {
        emAspas = !emAspas;
      }
      continue;
    }
    if (char === delimitador && !emAspas) {
      resultado.push(atual);
      atual = "";
      continue;
    }
    atual += char;
  }
  resultado.push(atual);
  return resultado;
}

async function buscarCoordenadasCsv(cep) {
  const base = await carregarBaseCep();
  if (!base) return null;
  return base[cep] || null;
}

async function carregarBaseCep() {
  if (cepBaseCache) return cepBaseCache;
  try {
    const response = await fetch(CEP_CSV);
    if (!response.ok) return null;
    const texto = await response.text();
    const registros = parseCsv(texto);
    const mapa = {};
    registros.forEach((item) => {
      const cep = String(item.cep || "").replace(/\D/g, "");
      if (!cep) return;
      const coords = extrairCentroide(item.centroide || item.centroide_wkt || "");
      if (!coords) return;
      mapa[cep] = {
        cep,
        cidade: item.nome_municipio || item.localidade || "-",
        estado: item.sigla_uf || "-",
        rua: item.logradouro || "-",
        bairro: item.localidade || "-",
        latitude: coords.latitude,
        longitude: coords.longitude,
      };
    });
    cepBaseCache = mapa;
    return cepBaseCache;
  } catch (error) {
    return null;
  }
}

function extrairCentroide(texto) {
  if (!texto) return null;
  const match = texto.match(/POINT\s*\(\s*([-0-9.,]+)\s+([-0-9.,]+)\s*\)/i);
  if (!match) return null;
  const longitude = normalizarNumero(match[1]);
  const latitude = normalizarNumero(match[2]);
  if (longitude === null || latitude === null) return null;
  return { latitude, longitude };
}

function normalizarAgencias(lista) {
  return lista
    .map((item) => ({
      codigo_agencia:
        item.codigo_agencia ||
        item.codigo ||
        item.codigoAgencia ||
        item.codigo_Agen ||
        item.codigo_Agencia ||
        item.codigo_agencia_1 ||
        "",
      nome_agencia: item.nome_agencia || item.nome || item.nomeAgencia || "",
      endereco: item.endereco || item.endereço || item.logradouro || "",
      municipio: item.municipio || item.cidade || "",
      uf: item.uf || item.estado || "",
      cep: item.cep || "",
      email_agencia: item.EMAIL || item.email || item.Email || "",
      email_regional: item.regional || item.REGIONAL || item.Regional || "",
      latitude: parseFloat(String(item.latitude || item.lat || "").replace(",", ".")),
      longitude: parseFloat(String(item.longitude || item.lng || "").replace(",", ".")),
    }))
    .filter(
      (item) =>
        item.codigo_agencia &&
        item.nome_agencia &&
        !Number.isNaN(item.latitude) &&
        !Number.isNaN(item.longitude)
    );
}

function calcularDistancias(localizacao, agencias) {
  const baseLat = parseFloat(localizacao.latitude);
  const baseLon = parseFloat(localizacao.longitude);
  if (Number.isNaN(baseLat) || Number.isNaN(baseLon)) return [];

  const calculado = agencias.map((agencia) => ({
    ...agencia,
    distancia_km: haversine(baseLat, baseLon, agencia.latitude, agencia.longitude),
  }));

  return calculado.sort((a, b) => a.distancia_km - b.distancia_km);
}

function haversine(lat1, lon1, lat2, lon2) {
  const raio = 6371;
  const dLat = degreesToRadians(lat2 - lat1);
  const dLon = degreesToRadians(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(degreesToRadians(lat1)) *
      Math.cos(degreesToRadians(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return raio * c;
}

function degreesToRadians(graus) {
  return graus * (Math.PI / 180);
}

function formatarMoeda(valor) {
  const numero = Number(valor);
  if (Number.isNaN(numero)) return valor;
  return numero.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function valorEmail(valor) {
  const texto = String(valor ?? "").trim();
  return texto && texto !== "-" ? texto : "Não informado";
}

function formatarMunicipioUfEmail(municipio, uf) {
  const partes = [municipio, uf]
    .map((valor) => String(valor ?? "").trim())
    .filter((valor) => valor && valor !== "-");
  return partes.length > 0 ? partes.join(" / ") : "Não informado";
}

function formatarCepEmail(cep) {
  const digitos = String(cep ?? "").replace(/\D/g, "");
  return digitos.length === 8 ? `${digitos.slice(0, 5)}-${digitos.slice(5)}` : valorEmail(cep);
}

function formatarDistanciaEmail(distancia) {
  const numero = Number(distancia);
  return Number.isFinite(numero)
    ? `${numero.toLocaleString("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 1 })} km`
    : "Não informado";
}

function formatarFaturamentoEmail(valor) {
  const numero = Number(valor);
  if (!Number.isFinite(numero)) return valorEmail(valor);
  if (numero >= 1000000000) {
    return `R$ ${(numero / 1000000000).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} bi`;
  }
  if (numero >= 1000000) {
    return `R$ ${(numero / 1000000).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} mi`;
  }
  return formatarMoeda(numero);
}

function parseValorMonetarioBR(valor) {
  if (valor === null || valor === undefined) return Number.NaN;
  let texto = String(valor).trim();
  if (!texto) return Number.NaN;
  texto = texto.replace(/[R$\s]/gi, "");
  const temVirgula = texto.includes(",");
  const temPonto = texto.includes(".");
  if (temVirgula && temPonto) {
    texto = texto.replace(/\./g, "").replace(",", ".");
  } else if (temVirgula) {
    texto = texto.replace(",", ".");
  }
  texto = texto.replace(/[^0-9.-]/g, "");
  const numero = parseFloat(texto);
  return Number.isNaN(numero) ? Number.NaN : numero;
}

async function fetchWithTimeout(url, timeoutMs) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error("NAO_ENCONTRADO");
      }
      if (response.status === 429) {
        throw new Error("MUITAS_REQUISICOES");
      }
      throw new Error("ERRO_API");
    }
    return await response.json();
  } catch (error) {
    if (error.name === "AbortError") {
      throw new Error("TIMEOUT");
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

function interpretarErro(error, tipo) {
  if (error.message === "NAO_ENCONTRADO") {
    return `${tipo} não encontrado.`;
  }
  if (error.message === "TIMEOUT") {
    return "Tempo de resposta excedido. Tente novamente.";
  }
  if (error.message === "MUITAS_REQUISICOES") {
    return "Limite de consultas atingido na API. Tente novamente em alguns minutos.";
  }
  if (error.message === "AGENCIA_BASE_VAZIA") {
    return "Base de agências vazia ou inválida.";
  }
  if (error.message === "XLSX_LIB_MISSING") {
    return "Biblioteca de leitura XLSX não disponível.";
  }
  return "Erro de rede ou API indisponível.";
}

resetarTela();
