export function initNavigation() {
  const header = document.querySelector(".site-header");
  const syncHeader = () => header?.classList.toggle("scrolled", scrollY > 24);
  syncHeader();
  addEventListener("scroll", syncHeader, { passive: true });

  const dropdown = document.querySelector("[data-nav-dropdown]");
  const trigger = dropdown?.querySelector(".nav-dropdown-trigger");
  const sublevel = dropdown?.querySelector("[data-nav-sublevel]");
  const sublevelTrigger = sublevel?.querySelector(".nav-sublevel-trigger");
  if (!dropdown || !trigger || !sublevel || !sublevelTrigger) return;

  const setDropdown = (open) => {
    dropdown.classList.toggle("open", open);
    trigger.setAttribute("aria-expanded", String(open));
  };
  const setSublevel = (open) => {
    sublevel.classList.toggle("open", open);
    sublevelTrigger.setAttribute("aria-expanded", String(open));
    sublevelTrigger.querySelector("i").className =
      `bi bi-chevron-${open ? "up" : "down"}`;
  };

  trigger.addEventListener("click", (event) => {
    event.stopPropagation();
    setDropdown(!dropdown.classList.contains("open"));
  });
  sublevelTrigger.addEventListener("click", (event) => {
    event.stopPropagation();
    setSublevel(!sublevel.classList.contains("open"));
  });
  document.addEventListener("click", (event) => {
    if (!dropdown.contains(event.target)) setDropdown(false);
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      setDropdown(false);
      trigger.focus();
    }
  });
}
