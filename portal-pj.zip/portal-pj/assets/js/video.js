export function initVideo() {
  const modal = document.querySelector("#videoModal");
  const video = document.querySelector("#institutionalVideo");
  if (!modal || !video) return;

  modal.addEventListener("shown.bs.modal", () => {
    video.play().catch(() => {});
  });
  modal.addEventListener("hidden.bs.modal", () => {
    video.pause();
  });
}
