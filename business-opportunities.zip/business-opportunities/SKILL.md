---
name: business-opportunities
description: Identifica e prioriza oportunidades comerciais elegíveis de aquisição, ativação, expansão e recuperação.
---

# Objetivo
Identifica e prioriza oportunidades comerciais elegíveis de aquisição, ativação, expansão e recuperação.

# Procedimento
Consulte carteira autorizada, elegibilidade, posse e utilização. Classifique oportunidades em aquisição, ativação, expansão e recuperação. Elimine duplicidades cliente-produto-período e respeite restrições. Quando disponíveis, use probabilidade calibrada de conversão e potencial incremental no horizonte da meta; valor esperado = probabilidade vezes potencial. Sem esses dados, apresente contagens e critérios qualitativos, sem inventar estimativas.

# Regras obrigatórias
Use somente dados autorizados e respeite permissões na origem. Priorize indicadores oficiais. Informe fonte, data de referência, filtros e unidade de medida. Se faltarem dados, explicite a limitação e solicite apenas o necessário. Não invente números nem execute ações comerciais. Consulte `references/validacao.md` antes de finalizar.

# Formato de saída
Ranking por unidade e tipo; público elegível; potencial bruto e esperado quando disponíveis; cobertura do gap; ação sugerida.
