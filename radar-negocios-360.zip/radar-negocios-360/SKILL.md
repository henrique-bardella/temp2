---
name: radar-negocios-360
description: "Analisa performance de produtos bancários, orçado versus realizado, atingimento, desvios, projeções e oportunidades comerciais. Use para diagnósticos executivos, riscos de meta e recomendações de ação."
---

# Radar de Negócios 360

## Objetivo
Transformar dados autorizados de performance em diagnóstico e ações comerciais priorizadas.

## Procedimento
1. Identifique produto, período, data de corte e escopo organizacional. Use o último período disponível se não especificado e informe essa escolha.
2. Consulte fontes autorizadas e indicadores oficiais. Não invente dados, não trate ausência como zero e não extrapole permissões.
3. Selecione os módulos abaixo conforme a pergunta. Para diagnóstico completo, execute todos na ordem indicada, quando houver dados suficientes.

## Módulos analíticos
- [product-performance](references/product-performance.md): consulte este procedimento quando pertinente.
- [budget-analysis](references/budget-analysis.md): consulte este procedimento quando pertinente.
- [performance-diagnosis](references/performance-diagnosis.md): consulte este procedimento quando pertinente.
- [business-opportunities](references/business-opportunities.md): consulte este procedimento quando pertinente.
- [performance-forecast](references/performance-forecast.md): consulte este procedimento quando pertinente.

## Regras obrigatórias
- Compare períodos e unidades equivalentes; use a meta proporcional oficial se disponível.
- Atingimento = realizado / orçado, se orçado positivo; gap = orçado - realizado. Consolide valores antes de calcular percentuais. Diferencie meta integral e proporcional.
- Classifique ofensores pelo desvio absoluto e contextualize pelo atingimento. Não trate correlação como causalidade.
- Projeções devem indicar método, horizonte, premissas e incerteza.
- Oportunidades devem respeitar elegibilidade, risco e permissões. Evite duplicidade e compare potencial incremental na mesma unidade e horizonte da meta. Sem probabilidade validada, não invente conversão.
- Não revele informações de clientes fora do escopo autorizado; não execute ações comerciais automaticamente.
- Consulte [validação](references/validacao.md) antes de responder.

## Resposta
Para análise completa, apresente resumo executivo, panorama, orçamento e gap, ofensores, tendência, oportunidades priorizadas e recomendações. Identifique fonte e data de referência, diferencie fatos de estimativas e indique limitações. Para perguntas pontuais, responda apenas o necessário.
