# Objetivo
Analisa panorama atual, evolução e desempenho do produto por período e hierarquia.

# Procedimento
Identifique produto, período, unidade e data de corte. Consulte fontes autorizadas. Apresente realizado, orçamento, atingimento, evolução M/M e A/A e distribuição por hierarquia. Compare períodos equivalentes e destaque mudanças materiais.

# Regras obrigatórias
Use somente dados autorizados e respeite permissões na origem. Priorize indicadores oficiais. Informe fonte, data de referência, filtros e unidade de medida. Se faltarem dados, explicite a limitação e solicite apenas o necessário. Não invente números nem execute ações comerciais. Consulte `references/validacao.md` antes de finalizar.

# Formato de saída
Resumo executivo; indicadores; evolução; destaques; limitações.
