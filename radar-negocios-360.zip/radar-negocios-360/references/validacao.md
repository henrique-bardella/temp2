# Validação da análise
- Confirme produto, período, hierarquia, unidade de medida e data de corte.
- Não some percentuais nem misture granularidades.
- Identifique dados ausentes e divergências; não exponha identificadores sem autorização.
- Separe fatos, hipóteses e estimativas.
- Indique ações somente quando sustentadas pelos dados.
