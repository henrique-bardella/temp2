// Busca global exibida no painel compartilhado do portal.
import { getJSON, normalize, url, el } from "./utils.js";

// Adapta páginas, soluções, documentos e banners para um formato comum de pesquisa.
const sources = [
  ["data/search-index.json", (items) => items],
  [
    "data/solutions.json",
    (items) =>
      items.map((item) => ({
        type: "Solução",
        title: item.title,
        description: item.shortDescription || item.description,
        keywords: [item.category, item.slugCategory, ...(item.benefits || [])],
        url: `pages/solucao.html?id=${item.id}`,
      })),
  ],
  [
    "data/documents.json",
    (items) =>
      items.map((item) => ({
        type: "Documento",
        title: item.title,
        description: item.description,
        keywords: [item.category, item.month, item.year, item.date],
        url: item.file,
      })),
  ],
  [
    "data/banners.json",
    (items) =>
      items.map((item) => ({
        type: "Destaque",
        title: item.title,
        description: item.subtitle,
        keywords: [item.eyebrow, item.buttonLabel],
        url: item.buttonUrl,
      })),
  ],
];

// Carrega as fontes em paralelo; uma falha não impede o uso das fontes que responderam.
async function buildIndex() {
  const loaded = await Promise.allSettled(
    sources.map(async ([file, adapt]) => adapt(await getJSON(file))),
  );
  // Remove repetições usando tipo, título normalizado e URL como chave.
  const unique = new Map();
  loaded
    .flatMap((source) => (source.status === "fulfilled" ? source.value : []))
    .forEach((item) => {
      const key = `${normalize(item.type)}|${normalize(item.title)}|${item.url}`;
      unique.set(key, item);
    });
  return [...unique.values()];
}

// Limpa os resultados anteriores; se não houver correspondências, informa ao usuário.
function renderResults(root, results) {
  root.replaceChildren();
  if (!results.length) {
    root.append(el("p", "text-white-50", "Nenhum resultado encontrado."));
    return;
  }
  // Agrupa os resultados por tipo e cria os títulos de grupo e links.
  const groups = results.reduce((map, item) => {
    const type = item.type || "Outros";
    if (!map.has(type)) map.set(type, []);
    map.get(type).push(item);
    return map;
  }, new Map());
  groups.forEach((items, type) => {
    root.append(el("h3", "eyebrow mt-4 mb-1", type));
    items.forEach((item) => {
      const link = el("a", "result-item");
      link.href = url(item.url);
      link.append(
        el("h4", "my-1", item.title),
        el("span", "text-white-50", item.description),
      );
      root.append(link);
    });
  });
}

// Conecta a busca apenas quando o painel, o campo e a saída existem na página.
export async function initSearch() {
  const overlay = document.querySelector(".search-overlay");
  const input = document.querySelector("#globalSearch");
  const output = document.querySelector("#searchResults");
  if (!overlay || !input || !output) return;
  // Monta o índice uma vez nesta inicialização; digitar não gera novas consultas aos JSON.
  const data = await buildIndex();
  // Abre o painel, aplica o estado ao body e leva o foco ao campo após 200 ms.
  const open = () => {
    overlay.classList.add("open");
    document.body.classList.add("search-open");
    setTimeout(() => input.focus(), 200);
  };
  // Remove o estado de abertura do painel e do body.
  const close = () => {
    overlay.classList.remove("open");
    document.body.classList.remove("search-open");
  };
  // Conecta os botões de abertura e fechamento; Escape também fecha o painel.
  document
    .querySelectorAll(".search-trigger")
    .forEach((button) => button.addEventListener("click", open));
  document.querySelector(".search-close")?.addEventListener("click", close);
  addEventListener("keydown", (event) => event.key === "Escape" && close());
  // Pesquisa a cada digitação e solicita ao menos dois caracteres.
  input.addEventListener("input", () => {
    const query = normalize(input.value.trim());
    if (query.length < 2) {
      output.replaceChildren(
        el(
          "p",
          "text-white-50",
          "Digite pelo menos 2 caracteres para começar.",
        ),
      );
      return;
    }
    // Procura o trecho digitado no título, descrição e palavras-chave combinados, sem acentos ou distinção de caixa.
    const results = data.filter((item) =>
      normalize(
        [item.title, item.description, ...(item.keywords || [])].join(" "),
      ).includes(query),
    );
    renderResults(output, results);
  });
}
