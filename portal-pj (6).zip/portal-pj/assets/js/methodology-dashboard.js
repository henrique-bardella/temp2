// Coordenadas proporcionais ao enquadramento das capturas atualizadas.
// A base de referência acompanha a proporção da imagem, independentemente da resolução.
export const dashboardAreas = [
  { image: 'dashboard-visao-geral.jpg', title: 'Filtros e navegação de páginas', description: 'Na lateral esquerda, escolha a página e delimite cargo, segmento, regional, agência e funcionário. Confira os filtros antes de interpretar os resultados.', x: 0, y: 108, width: 238, height: 848, imageWidth: 2048, imageHeight: 1026 },
  { image: 'dashboard-visao-geral.jpg', title: 'Identificação do profissional', description: 'Ao selecionar os filtros e o funcionário, o cabeçalho apresenta as informações do profissional, incluindo cargo, tempo na função, agência e regional. Confirme a quem os resultados se referem. Os dados de identificação pessoal estão borrados nesta demonstração.', x: 250, y: 8, width: 570, height: 86, imageWidth: 2048, imageHeight: 1026 },
  { image: 'dashboard-visao-geral.jpg', title: 'Indicadores de desempenho', description: 'Compare atingimento, peso e contribuição dos indicadores de Resultado e Consistência nas leituras de 12 meses e YTD.', x: 493, y: 146, width: 1135, height: 264, imageWidth: 2048, imageHeight: 1026 },
  { image: 'dashboard-visao-geral.jpg', title: 'Pontuação ICG', description: 'Observe a pontuação consolidada nas leituras de 12 meses e YTD.', x: 243, y: 146, width: 245, height: 264, imageWidth: 2048, imageHeight: 1026 },
  { image: 'dashboard-visao-geral.jpg', title: 'Nine Box YTD', description: 'Localize a posição acumulada no ano e leia o direcionamento associado ao quadrante.', x: 242, y: 416, width: 906, height: 366, imageWidth: 2048, imageHeight: 1026 },
  { image: 'dashboard-visao-geral.jpg', title: 'Nine Box — 12 meses', description: 'Compare a posição na janela móvel de 12 meses para avaliar a sustentabilidade da entrega.', x: 1150, y: 416, width: 898, height: 366, imageWidth: 2048, imageHeight: 1026 },
  { image: 'dashboard-visao-geral.jpg', title: 'Scores dos eixos', description: 'Identifique as contribuições por indicador, os scores dos eixos e suas classificações.', x: 245, y: 805, width: 1790, height: 118, imageWidth: 2048, imageHeight: 1026 },
  { image: 'dashboard-historicos.jpg', title: 'Históricos', description: 'Acompanhe a evolução mensal dos atingimentos para avaliar tendência, estabilidade e volatilidade.', x: 245, y: 106, width: 1106, height: 516, imageWidth: 2048, imageHeight: 1029 },
  { image: 'dashboard-historicos.jpg', title: 'Perfil de competências', description: 'Compare o desempenho atual com o histórico no gráfico de perfil de competências.', x: 1370, y: 116, width: 430, height: 360, imageWidth: 2048, imageHeight: 1029 },
  { image: 'dashboard-visao-geral.jpg', title: 'Guidance', description: 'Observe a posição na Nine Box dos últimos 12 meses e leia o guidance correspondente ao quadrante para orientar o desenvolvimento gerencial.', x: 1825, y: 445, width: 223, height: 230, imageWidth: 2048, imageHeight: 1026 },
];

export function initDashboardGuide() {
  const dialog = document.querySelector('#dashboard-guide');
  if (!dialog) return;
  const title = dialog.querySelector('#dashboard-guide-title');
  const description = dialog.querySelector('#dashboard-guide-description');
  const viewport = dialog.querySelector('.dashboard-guide-crop');
  const image = dialog.querySelector('img');
  const highlight = dialog.querySelector('.dashboard-guide-highlight');
  const zoom = dialog.querySelector('[data-toggle-guide-zoom]');
  const caption = dialog.querySelector('#dashboard-guide-caption');
  const status = dialog.querySelector('[role="status"]');
  let trigger;
  let currentArea;
  let expanded = false;

  function renderView() {
    const area = currentArea;
    viewport.style.aspectRatio = expanded ? `${area.width} / ${area.height}` : `${area.imageWidth} / ${area.imageHeight}`;
    viewport.style.maxWidth = expanded ? `${Math.max(area.width, 420)}px` : '100%';
    image.style.width = expanded ? `${area.imageWidth / area.width * 100}%` : '100%';
    image.style.left = expanded ? `${-area.x / area.width * 100}%` : '0';
    image.style.top = expanded ? `${-area.y / area.height * 100}%` : '0';
    image.alt = expanded ? `Trecho do dashboard: ${area.title}. ${area.description}` : `Dashboard ${area.image.includes('historicos') ? 'Históricos' : 'Visão Geral'}, com a área de ${area.title} destacada.`;
    highlight.hidden = expanded;
    highlight.style.left = `${area.x / area.imageWidth * 100}%`;
    highlight.style.top = `${area.y / area.imageHeight * 100}%`;
    highlight.style.width = `${area.width / area.imageWidth * 100}%`;
    highlight.style.height = `${area.height / area.imageHeight * 100}%`;
    zoom.textContent = expanded ? 'Ver dashboard completo' : 'Ampliar trecho';
    zoom.setAttribute('aria-pressed', String(expanded));
    caption.textContent = expanded ? 'Trecho ampliado para leitura dos detalhes.' : 'A área destacada mostra onde encontrar este item no dashboard.';
  }
  zoom.addEventListener('click', () => {
    expanded = !expanded;
    renderView();
  });

  document.querySelectorAll('.reading-journey li').forEach((item, index) => {
    const area = dashboardAreas[index];
    if (!area) return;
    const content = item.querySelector('div');
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'dashboard-guide-trigger';
    button.setAttribute('aria-haspopup', 'dialog');
    button.setAttribute('aria-controls', dialog.id);
    const heading = content.querySelector('h3');
    const label = document.createElement('span');
    label.className = 'dashboard-guide-heading';
    label.textContent = heading.textContent;
    const copy = document.createElement('span');
    copy.className = 'dashboard-guide-copy';
    copy.textContent = content.querySelector('p').textContent;
    const action = document.createElement('span');
    action.className = 'dashboard-guide-action';
    action.textContent = 'Ver localização no dashboard →';
    button.append(label, copy, action);
    content.replaceWith(button);
    button.addEventListener('click', () => {
      trigger = button;
      currentArea = area;
      expanded = false;
      zoom.disabled = true;
      title.textContent = area.title;
      description.textContent = area.description;
      viewport.hidden = true;
      status.hidden = false;
      status.textContent = 'Carregando imagem…';
      renderView();
      image.onload = () => { viewport.hidden = false; status.hidden = true; zoom.disabled = false; };
      image.onerror = () => { status.textContent = 'A imagem deste dashboard ainda não está disponível.'; };
      image.src = new URL(`../images/${area.image}`, import.meta.url).href;
      dialog.showModal();
      dialog.scrollTop = 0;
      document.body.classList.add('dashboard-guide-open');
    });
  });
  dialog.querySelector('[data-close-guide]').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
  dialog.querySelector('.dashboard-guide-content').addEventListener('click', (event) => event.stopPropagation());
  dialog.addEventListener('close', () => {
    document.body.classList.remove('dashboard-guide-open');
    trigger?.focus();
  });
}

if (typeof document !== 'undefined') initDashboardGuide();
