// Controla a prévia e a reprodução do vídeo editorial.
export function initVideo() {
  // Só inicializa quando encontra o vídeo, o botão e seu contêiner.
  const video = document.querySelector(".video-thumbnail");
  const playButton = document.querySelector("[data-video-play]");
  const media = video?.closest(".editorial-media");
  if (!video || !playButton || !media) return;

  // Posiciona o vídeo perto do início para a prévia; aguarda metadados se necessário.
  const showFrame = () => {
    video.currentTime = Math.min(0.1, video.duration || 0.1);
  };
  if (video.readyState >= 1) showFrame();
  else video.addEventListener("loadedmetadata", showFrame, { once: true });

  // Exibe controles nativos e inicia a reprodução; uma recusa de play é capturada sem mensagem.
  playButton.addEventListener("click", () => {
    video.controls = true;
    media.classList.add("is-playing");
    video.play().catch(() => {});
  });

  // Ao terminar, restaura o estado visual inicial e o quadro de prévia.
  video.addEventListener("ended", () => {
    video.controls = false;
    media.classList.remove("is-playing");
    showFrame();
  });
}
