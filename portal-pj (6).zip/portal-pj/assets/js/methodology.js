// Pesos fornecidos para a documentação; não alteram cálculos de outras páginas.
export const indicators = [
  { name: 'ROB Crédito', weights: [25, 25, 20, 25], attainment: 125 },
  { name: 'ROB Não Crédito', weights: [20, 15, 15, 15], attainment: 92 },
  { name: 'TPV', weights: [15, 15, 20, 15], attainment: 108 },
  { name: 'Faturamento Líquido', weights: [15, 15, 15, 15], attainment: 101 },
  { name: 'BSC', weights: [15, 15, 10, 15], attainment: 97 },
  { name: 'EncantaBra', weights: [10, 10, 10, 10], attainment: 103 },
  { name: 'Discricionário', weights: [0, 5, 10, 5], attainment: 90 },
];
const roles = ['GC', 'AG', 'GR', 'GG'];
const number = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function calculateExample(role) {
  const index = roles.indexOf(role);
  if (index < 0) throw new Error('Cargo inválido');
  const rows = indicators.filter((item) => item.weights[index] > 0).map((item) => ({
    name: item.name, attainment: item.attainment, weight: item.weights[index], points: item.attainment / 100 * item.weights[index],
  }));
  return {
    result: indicators.slice(0, 4).reduce((sum, item) => sum + item.weights[index], 0),
    consistency: indicators.slice(4).reduce((sum, item) => sum + item.weights[index], 0),
    rows, total: rows.reduce((sum, item) => sum + item.points, 0),
  };
}

function renderRole(role) {
  const example = calculateExample(role);
  document.querySelectorAll('[data-methodology-role]').forEach((button) => {
    const selected = button.dataset.methodologyRole === role;
    button.classList.toggle('active', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  document.querySelectorAll('[data-role-column]').forEach((cell) => {
    cell.dataset.selected = String(cell.dataset.roleColumn === role);
  });
  document.querySelectorAll('[data-axis-max]').forEach((node) => {
    node.textContent = example[node.dataset.axisMax];
  });
  document.querySelectorAll('[data-role-label]').forEach((node) => {
    node.textContent = role;
  });
  document.querySelector('#methodology-cuts').innerHTML = ['result', 'consistency'].map((axis) => {
    const max = example[axis];
    return `<article class="card-premium methodology-card mb-3"><h3>${axis === 'result' ? 'Resultado' : 'Consistência'} · ${role} · máximo ${max} pts</h3><p>Faixa baixa: score &lt; ${number.format(max * .8)} pts.<br>Faixa média: ${number.format(max * .8)} até ${number.format(max * .95)} pts, inclusive.<br>Faixa alta: score &gt; ${number.format(max * .95)} pts.</p></article>`;
  }).join('');
  document.querySelector('#icg-example').innerHTML = example.rows.map((row) => `<tr><th scope="row">${row.name}</th><td>${row.attainment}%</td><td>${row.weight}%</td><td>${number.format(row.points)}</td></tr>`).join('');
  document.querySelector('#icg-total').textContent = `${number.format(example.total)} pts`;
}

if (typeof document !== 'undefined' && document.querySelector('.methodology-page')) {
  document.querySelectorAll('[data-methodology-role]').forEach((button) => {
    button.addEventListener('click', () => renderRole(button.dataset.methodologyRole));
  });
  renderRole('GC');
}
