// Lista documentos com busca local, filtros de mês e ano e ordenação por data.
import { getJSON, url, el, normalize } from "./utils.js";
export async function initDocuments() {
  // Executa apenas se a página tiver documentsGrid.
  const grid = document.querySelector("#documentsGrid");
  if (!grid) return;
  // Carrega data/documents.json; em caso de falha, exibe indisponibilidade e encerra.
  let docs = [];
  try {
    docs = await getJSON("data/documents.json");
  } catch {
    grid.innerHTML = '<div class="empty">Documentos indisponíveis.</div>';
    return;
  }
  // Localiza os campos usados para filtrar e ordenar a lista.
  const month = document.querySelector("#month"),
    year = document.querySelector("#year"),
    sort = document.querySelector("#sortDocs"),
    q = document.querySelector("#docSearch");
  // Preenche o seletor com os anos cadastrados, sem repetições.
  [...new Set(docs.map((d) => d.year))].forEach((v) =>
    year.add(new Option(v, v)),
  );
  // Combina mês, ano e pesquisa no título e na descrição, ignorando acentos e maiúsculas.
  const render = () => {
    let list = docs.filter(
      (d) =>
        (!month.value || d.month == month.value) &&
        (!year.value || d.year == year.value) &&
        normalize(d.title + " " + d.description).includes(normalize(q.value)),
    );
    // Compara datas ISO: old mostra as mais antigas primeiro; as outras opções invertem a ordem.
    list.sort(
      (a, b) => (sort.value === "old" ? 1 : -1) * a.date.localeCompare(b.date),
    );
    // Recria os cards com data em português e link para o PDF em nova aba.
    grid.replaceChildren(
      ...list.map((d) => {
        const c = el("div", "col-md-6 col-lg-4");
        c.innerHTML = `<article class="card-premium card-body-custom"><span class="eyebrow">${new Date(d.date + "T12:00").toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</span><h3 class="mt-3">${d.title}</h3><p>${d.description}</p><a class="btn-ghost mt-3" href="${url(d.file)}" target="_blank">Abrir PDF <span>↗</span></a></article>`;
        return c;
      }),
    );
    // Informa quando nenhum documento corresponde aos filtros.
    if (!list.length)
      grid.innerHTML = '<div class="empty">Nenhum documento encontrado.</div>';
  };
  // Atualiza a lista ao alterar qualquer controle e renderiza o conteúdo inicial.
  [month, year, sort, q].forEach((x) => x.addEventListener("input", render));
  render();
}
