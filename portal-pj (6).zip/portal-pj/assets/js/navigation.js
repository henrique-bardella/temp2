// Controla o cabeçalho e a abertura dos menus e submenus.
export function initNavigation() {
  // Aplica scrolled ao cabeçalho após 24 pixels de rolagem, inclusive no carregamento inicial.
  const header = document.querySelector(".site-header");
  const syncHeader = () => header?.classList.toggle("scrolled", scrollY > 24);
  syncHeader();
  addEventListener("scroll", syncHeader, { passive: true });

  // Localiza os menus expansíveis; closeDropdown remove open e atualiza aria-expanded.
  const dropdowns = [...document.querySelectorAll("[data-nav-dropdown]")];
  const closeDropdown = (dropdown) => {
    dropdown.classList.remove("open");
    dropdown
      .querySelector(".nav-dropdown-trigger")
      ?.setAttribute("aria-expanded", "false");
  };

  // Alterna o menu clicado e fecha os demais. stopPropagation impede o fechamento pelo mesmo clique no documento.
  dropdowns.forEach((dropdown) => {
    const trigger = dropdown.querySelector(".nav-dropdown-trigger");
    trigger?.addEventListener("click", (event) => {
      event.stopPropagation();
      const willOpen = !dropdown.classList.contains("open");
      dropdowns.forEach(closeDropdown);
      dropdown.classList.toggle("open", willOpen);
      trigger.setAttribute("aria-expanded", String(willOpen));
    });

    // Alterna os submenus e atualiza o estado acessível e a seta de direção.
    dropdown.querySelectorAll("[data-nav-sublevel]").forEach((sublevel) => {
      const sublevelTrigger = sublevel.querySelector(".nav-sublevel-trigger");
      sublevelTrigger?.addEventListener("click", (event) => {
        event.stopPropagation();
        const open = !sublevel.classList.contains("open");
        sublevel.classList.toggle("open", open);
        sublevelTrigger.setAttribute("aria-expanded", String(open));
        sublevelTrigger.querySelector("i").className =
          `bi bi-chevron-${open ? "up" : "down"}`;
      });
    });
  });
  // Fecha os menus quando o usuário clica fora deles.
  document.addEventListener("click", (event) => {
    dropdowns.forEach((dropdown) => {
      if (!dropdown.contains(event.target)) closeDropdown(dropdown);
    });
  });
  // Escape fecha o menu aberto e devolve o foco ao botão que o controla.
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      const openDropdown = dropdowns.find((item) =>
        item.classList.contains("open"),
      );
      const trigger = openDropdown?.querySelector(".nav-dropdown-trigger");
      if (openDropdown) closeDropdown(openDropdown);
      trigger?.focus();
    }
  });
}
