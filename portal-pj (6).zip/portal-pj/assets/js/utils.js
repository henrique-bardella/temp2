// Lê data-base do body para resolver caminhos; sem esse atributo, usa a pasta atual.
export const base = () => document.body.dataset.base || "./";
// Prefixa um caminho local com a base. Esta função não trata endereços externos de forma especial.
export const url = (p) => `${base()}${p}`;
// Busca um JSON pelo servidor HTTP e lança erro se a resposta indicar falha.
export async function getJSON(path) {
  const r = await fetch(url(path));
  if (!r.ok) throw new Error(`Não foi possível carregar ${path}`);
  return r.json();
}
// Remove acentos e converte para minúsculas para comparar textos nas buscas.
export const normalize = (s) =>
  (s || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
// Cria um elemento com classe e texto opcionais; textContent insere texto sem interpretar HTML.
export const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text) n.textContent = text;
  return n;
};
