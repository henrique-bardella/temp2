// Monta o catálogo de soluções e os detalhes de uma solução selecionada.
import { getJSON, url, el } from "./utils.js";
// Cria um card a partir do JSON, com categoria, imagem, descrição curta e link de detalhes.
const card = (s) => {
  const col = el("div", "col-md-6 col-xl-4 solution-item");
  col.dataset.category = s.slugCategory;
  const art = el("article", "card-premium");
  const media = el("div", "card-media");
  const img = el("img");
  img.src = url(s.image);
  img.alt = "";
  // Carrega a imagem sob demanda e a remove se o arquivo falhar.
  img.loading = "lazy";
  img.onerror = () => img.remove();
  media.append(img);
  const body = el("div", "card-body-custom");
  body.append(
    el("span", "eyebrow", s.category),
    el("h3", "", s.title),
    el("p", "", s.shortDescription),
  );
  const a = el("a", "btn-ghost mt-2", "Conheça →");
  a.href = url(`pages/solucao.html?id=${s.id}`);
  body.append(a);
  art.append(media, body);
  col.append(art);
  return col;
};
// Carrega data/solutions.json somente quando existe a grade solutionsGrid.
export async function initSolutions() {
  const grid = document.querySelector("#solutionsGrid");
  if (!grid) return;
  try {
    const data = await getJSON("data/solutions.json");
    grid.replaceChildren(...data.map(card));
    // Os botões destacam o filtro escolhido e ocultam cards de outras categorias; all mostra todos.
    document.querySelectorAll("[data-filter]").forEach((b) =>
      b.addEventListener("click", () => {
        document
          .querySelectorAll("[data-filter]")
          .forEach((x) => x.classList.remove("active"));
        b.classList.add("active");
        grid
          .querySelectorAll(".solution-item")
          .forEach(
            (c) =>
              (c.hidden =
                b.dataset.filter !== "all" &&
                c.dataset.category !== b.dataset.filter),
          );
      }),
    );
  } catch {
    grid.innerHTML =
      '<div class="empty">Soluções temporariamente indisponíveis.</div>';
  }
}
// Busca o registro pelo parâmetro id da URL para preencher a página de detalhe.
export async function initSolutionDetail() {
  const root = document.querySelector("#solutionDetail");
  if (!root) return;
  try {
    const all = await getJSON("data/solutions.json"),
      s = all.find(
        (x) => x.id === new URLSearchParams(location.search).get("id"),
      );
    // Um id não encontrado leva à mensagem de solução indisponível no bloco catch.
    if (!s) throw 0;
    // Preenche o título da aba e os campos de texto marcados no HTML.
    document.title = `${s.title} | Portal PJ`;
    root.querySelector("[data-title]").textContent = s.title;
    root.querySelector("[data-subtitle]").textContent = s.shortDescription;
    root.querySelector("[data-description]").textContent = s.description;
    // Transforma os benefícios cadastrados em cards na área data-benefits.
    const benefits = root.querySelector("[data-benefits]");
    benefits.replaceChildren(
      ...s.benefits.map((x) => {
        const d = el("div", "col-md-4");
        d.innerHTML = `<div class="card-premium card-body-custom"><i class="bi bi-check-circle text-danger fs-3"></i><h3 class="mt-3">${x}</h3></div>`;
        return d;
      }),
    );
  } catch {
    root.innerHTML =
      '<section class="page-hero"><div class="container"><p class="eyebrow">Conteúdo não encontrado</p><h1>Esta solução não está disponível.</h1><a class="btn-brand mt-4" href="solucoes.html">Ver soluções →</a></div></section>';
  }
}
