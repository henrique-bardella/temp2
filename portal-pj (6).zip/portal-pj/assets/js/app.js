// Ponto de entrada: importa os módulos usados pelas páginas do portal.
import { loadComponents } from "./components.js";
import { initNavigation } from "./navigation.js";
import { initCarousel } from "./carousel.js";
import { initSearch } from "./search.js";
import { initSolutions, initSolutionDetail } from "./solutions.js";
import { initDocuments } from "./documents.js";
import { initVideo } from "./video.js";
import { initLives } from "./lives.js";
// Aguarda cabeçalho, rodapé e busca antes de inicializar os recursos que usam esses elementos.
await loadComponents();
// Ativa os recursos. Cada módulo de conteúdo verifica sua área; lives também atualiza o menu.
initLives();
initNavigation();
initCarousel();
initSearch();
initSolutions();
initSolutionDetail();
initDocuments();
initVideo();
// Observa elementos com animação de entrada. Ao atingir 12% de visibilidade, aplica visible e deixa de observar.
const io = new IntersectionObserver(
  (es) =>
    es.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add("visible");
        io.unobserve(e.target);
      }
    }),
  { threshold: 0.12 },
);
// Registra os elementos marcados com reveal para a animação de entrada.
document.querySelectorAll(".reveal").forEach((x) => io.observe(x));
