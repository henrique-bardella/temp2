// Central analítica: pesquisa e filtros locais, sem modificar a busca global.
import { getJSON, normalize, url, el } from "./utils.js";

// Aceita links HTTP(S) externos e caminhos relativos à raiz do portal.
// Campos vazios ou protocolos inadequados não geram links clicáveis.
export function analyticsURL(value) {
  if (typeof value !== "string" || !value.trim()) return null;
  const raw = value.trim();
  try {
    const target = new URL(/^[a-z][a-z\d+.-]*:/i.test(raw) || raw.startsWith("/") ? raw : url(raw), location.href);
    return ["https:", "http:"].includes(target.protocol) && !target.username && !target.password ? target.href : null;
  } catch { return null; }
}

// Todos os filtros são combinados. Registros para "Todos" atendem a qualquer público.
export function filterDashboards(items, query, theme, audience) {
  const terms = normalize(query).trim().split(/\s+/).filter(Boolean);
  return items.filter(item => {
    const text = normalize([item.title, item.description, item.theme, ...item.audiences].join(" "));
    return (!theme || item.theme === theme)
      && (!audience || item.audiences.includes(audience) || item.audiences.includes("Todos"))
      && terms.every(term => text.includes(term));
  });
}

// Cria ações com identificação acessível e abre os destinos em nova aba.
function action(label, href, cls, title) {
  const link = el("a", cls, label);
  link.href = href;
  link.target = "_blank";
  link.rel = "noopener noreferrer";
  link.setAttribute("aria-label", `${label}: ${title} (abre em nova aba)`);
  return link;
}

// Um cadastro com documentação recebe dois botões; os demais recebem apenas acesso.
function createCard(item) {
  const card = el("article", "card-premium analytics-card");
  const top = el("div", "analytics-card-top");
  const icon = el("i", `bi ${/^bi-[a-z0-9-]+$/.test(item.icon || "") ? item.icon : "bi-grid-1x2-fill"} analytics-icon`);
  icon.setAttribute("aria-hidden", "true");
  top.append(icon, el("span", "analytics-tag", item.theme));
  card.append(top, el("h2", "", item.title));
  if (item.description) {
    // Permite focar a descrição para rolar textos longos também pelo teclado.
    const description = el("p", "analytics-description", item.description);
    description.tabIndex = 0;
    description.setAttribute("role", "region");
    description.setAttribute("aria-label", `Descrição: ${item.title}`);
    card.append(description);
  }
  const footer = el("div", "analytics-card-footer");
  footer.append(el("p", "analytics-meta", [item.audiences.join(", "), item.updatedLabel].filter(Boolean).join(" · ")));
  const actions = el("div", "analytics-actions");
  const documentation = analyticsURL(item.documentationUrl);
  if (documentation) actions.append(action("Documentação", documentation, "btn-ghost", item.title));
  const dashboard = analyticsURL(item.dashboardUrl);
  if (dashboard) actions.append(action("Acessar", dashboard, "btn-brand", item.title));
  else {
    const unavailable = el("button", "btn-brand", "Acesso em breve");
    unavailable.type = "button";
    unavailable.disabled = true;
    actions.append(unavailable);
  }
  footer.append(actions);
  card.append(footer);
  return card;
}

// Carrega o cadastro uma vez; toda pesquisa posterior acontece em memória.
async function initAnalytics() {
  const grid = document.querySelector("#analyticsGrid");
  if (!grid) return;
  const search = document.querySelector("#analyticsSearch");
  const audience = document.querySelector("#analyticsAudience");
  const themes = document.querySelector("#analyticsThemes");
  const status = document.querySelector("#analyticsStatus");
  const clear = document.querySelector("#analyticsClear");
  let theme = "";
  try {
    const items = await getJSON("data/analytics.json");
    if (!Array.isArray(items) || items.some(item => !item || typeof item.title !== "string" || !item.title.trim() || typeof item.theme !== "string" || !Array.isArray(item.audiences) || item.audiences.some(value => typeof value !== "string"))) throw new Error("Cadastro inválido");
    // Os temas e públicos são derivados do JSON para facilitar novos cadastros.
    const availableThemes = [...new Set(items.map(item => item.theme))];
    const availableAudiences = [...new Set(items.flatMap(item => item.audiences))].filter(value => value !== "Todos").sort((a, b) => a.localeCompare(b, "pt-BR"));
    availableAudiences.forEach(value => audience.add(new Option(value, value)));
    const render = () => {
      const selected = filterDashboards(items, search.value, theme, audience.value);
      grid.replaceChildren(...selected.map(createCard));
      if (!selected.length) grid.append(el("p", "analytics-empty", items.length ? "Nenhum dashboard encontrado. Tente outro termo ou limpe os filtros." : "Os dashboards serão disponibilizados em breve."));
      status.textContent = `${selected.length} ${selected.length === 1 ? "resultado" : "resultados"}`;
      clear.hidden = !search.value && !theme && !audience.value;
    };
    ["", ...availableThemes].forEach(value => {
      const button = el("button", "", value || "Todos");
      button.type = "button";
      button.setAttribute("aria-pressed", String(value === theme));
      button.setAttribute("aria-controls", "analyticsGrid");
      button.addEventListener("click", () => {
        theme = value;
        themes.querySelectorAll("button").forEach(other => other.setAttribute("aria-pressed", String(other === button)));
        render();
      });
      themes.append(button);
    });
    search.addEventListener("input", render);
    audience.addEventListener("change", render);
    clear.addEventListener("click", () => {
      search.value = "";
      audience.value = "";
      theme = "";
      themes.querySelectorAll("button").forEach((button, index) => button.setAttribute("aria-pressed", String(index === 0)));
      render();
      search.focus();
    });
    search.disabled = audience.disabled = false;
    render();
  } catch {
    status.textContent = "Não foi possível carregar os dashboards. Recarregue a página para tentar novamente.";
  } finally { grid.setAttribute("aria-busy", "false"); }
}
initAnalytics();
