// Monta caminhos usando o data-base do <body>: "./" na inicial e "../" nas páginas internas.
import { url } from "./utils.js";

// Páginas que destacam o menu "Por dentro da PJ" quando estão abertas.
const insideSection = new Set([
  "empresas.html",
  "negocios.html",
  "plataforma-pj.html",
  "mei-digital.html",
  "inteligencia-analitica.html",
  "solucoes.html",
  "solucao.html",
  "documentos.html",
  "sobre.html",
  "agendamentos.html",
]);
// Chamada por app.js antes de inicializar a navegação e outros recursos.
// Carrega os componentes compartilhados, ajusta seus links e destaca o menu atual.
export async function loadComponents() {
  // Associa cada espaço reservado no HTML ao arquivo do componente:
  // app-header = cabeçalho; app-footer = rodapé; app-search = busca global.
  for (const [selector, file] of [
    ["#app-header", "components/header.html"],
    ["#app-footer", "components/footer.html"],
    ["#app-search", "components/search-overlay.html"],
  ]) {
    // Se a página não tiver esse espaço reservado, pula apenas esse componente.
    const node = document.querySelector(selector);
    if (!node) continue;
    try {
      // Busca o HTML pelo servidor HTTP e insere o conteúdo no elemento da página.
      const response = await fetch(url(file));
      if (!response.ok) throw new Error();
      node.innerHTML = await response.text();
    } catch {
      // Exibe uma mensagem no local do componente caso a requisição falhe.
      node.innerHTML = '<div class="empty">Componente indisponível.</div>';
    }
  }
  // Converte data-route em href, respeitando a pasta em que a página está.
  // Exemplo: data-route="pages/capacitacao.html" vira um link navegável.
  document
    .querySelectorAll("[data-route]")
    .forEach((link) => (link.href = url(link.dataset.route)));
  // Define o caminho do logotipo em todas as imagens marcadas com data-logo.
  document
    .querySelectorAll("[data-logo]")
    .forEach((image) => (image.src = url("assets/images/logo-bradesco.png")));
  // Obtém o nome do arquivo aberto, sem os parâmetros da URL.
  // Quando o endereço termina em uma pasta, considera a página inicial.
  const page = location.pathname.split("/").pop() || "index.html";
  // Remove o destaque anterior antes de identificar os links da página atual.
  document
    .querySelectorAll(".nav-link")
    .forEach((link) => link.classList.remove("active"));
  // Procura a página entre os links diretos do menu desktop.
  // O detalhe live.html mantém "Lives" destacado, pois pertence a essa área.
  const desktop = [
      ...document.querySelectorAll(".desktop-nav>.nav-link[data-route]"),
    ],
    current = desktop.find(
      (link) => new URL(link.href).pathname.split("/").pop() === (page === "live.html" ? "lives.html" : page),
    );
  if (current) current.classList.add("active");
  // Destaca o menu pai das páginas que ficam em grupos:
  // conteúdos e capacitação -> "Dia a dia" (primeiro nav-dropdown-trigger);
  // resultados -> "Meus resultados"; páginas de insideSection -> "Por dentro da PJ".
  // O operador ?. evita erro caso o elemento do menu não exista na página.
  if (["conteudos.html", "capacitacao.html"].includes(page))
    document.querySelector(".nav-dropdown-trigger")?.classList.add("active");
  else if (["resultados.html", "metodologia.html"].includes(page))
    document.querySelector(".results-dropdown-trigger")?.classList.add("active");
  else if (insideSection.has(page))
    document
      .querySelector('.desktop-nav [data-section="pj"]')
      ?.classList.add("active");
  if (page === "metodologia.html") {
    document.querySelectorAll('[data-route="pages/metodologia.html"]').forEach((link) => {
      link.classList.add("active");
      link.setAttribute("aria-current", "page");
    });
    document.querySelector(".mobile-nav-group")?.setAttribute("open", "");
  }
  // No menu mobile, destaca os links cujo arquivo corresponde à página aberta.
  // Aqui também trata o detalhe de uma live como parte da página de Lives.
  document
    .querySelectorAll("#mobileNav .nav-link[data-route]")
    .forEach((link) => {
      if (new URL(link.href).pathname.split("/").pop() === (page === "live.html" ? "lives.html" : page))
        link.classList.add("active");
    });
}

// Marca também o item Metodologia dentro do submenu de resultados.
