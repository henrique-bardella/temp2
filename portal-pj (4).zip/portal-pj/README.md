# Portal PJ

## Inteligência Analítica

Acesse `pages/inteligencia-analitica.html` pelo menu **Por dentro da PJ**. A página possui busca local sem distinção de acentos, filtros combinados por tema e público e a ação de limpar filtros.

Edite `data/analytics.json` para cadastrar os dashboards. Os registros iniciais são modelos baseados na referência visual; confirme textos, públicos e periodicidades antes de publicar. Os links foram deixados vazios porque os endereços reais não foram fornecidos.

```json
{
  "id": "meu-dashboard",
  "title": "Meu dashboard",
  "description": "Descrição opcional do material.",
  "theme": "GDAD",
  "audiences": ["Matriz", "Rede"],
  "icon": "bi-grid-1x2-fill",
  "updatedLabel": "Atualizado mensalmente",
  "dashboardUrl": "https://seu-endereco-do-dashboard",
  "documentationUrl": "pdfs/meu-guia.pdf"
}
```

Substitua os endereços do exemplo pelos reais e inclua o PDF na pasta indicada. Caminhos locais partem da raiz do portal, sem `../`. Links externos HTTP(S) também são aceitos e abrem em nova aba. Com `documentationUrl` vazio, há apenas a ação de acesso; preenchido com um endereço válido, aparece também **Documentação**. Sem `dashboardUrl`, a ação fica desabilitada como **Acesso em breve**.

Os temas e públicos são gerados automaticamente a partir dos registros. Use `audiences: ["Todos"]` para um material que deve aparecer em qualquer filtro de público. A descrição pode ser vazia; o rodapé com ações continua alinhado nos cards da mesma linha. Para adicionar temas como Produto e Campanha, cadastre materiais com esses valores em `theme`.

Arquivos da funcionalidade: `pages/inteligencia-analitica.html`, `assets/css/analytics.css`, `assets/js/analytics.js` e `data/analytics.json`. A integração usa também `components/header.html`, `assets/js/components.js` e `data/search-index.json`.

## Lives no Teams

Abra `pages/lives.html` para consultar a agenda. Cada encontro tem uma página em `pages/live.html?id=ID`, com acesso ao Teams em nova aba. O menu destaca lives em andamento, e a página inicial exibe uma chamada quando há uma live ativa.

Cadastre os encontros em `data/lives.json` (inicialmente vazio), usando este formato:

```json
[
  {
    "id": "encontro-pj",
    "title": "Encontro do Portal PJ",
    "description": "Temas e orientações para o dia a dia.",
    "speaker": "Equipe Portal PJ",
    "startsAt": "2026-10-15T14:00:00-03:00",
    "endsAt": "2026-10-15T15:00:00-03:00",
    "status": "auto",
    "teamsUrl": ""
  }
]
```

Substitua as datas e preencha `teamsUrl` com o link HTTPS real do convite do Teams. Sem link, a página informa que o acesso será disponibilizado em breve. Use IDs únicos e datas ISO com fuso horário; o fim deve ser posterior ao início.

Com `status: "auto"` (ou sem status), o indicador usa o horário do dispositivo e o intervalo cadastrado: próxima antes do início, ao vivo durante o intervalo e encerrada após o fim. Ele **não consulta a transmissão no Teams**. Para controlar atrasos, encerramentos antecipados ou cancelamentos, use `live`, `ended` ou `cancelled` e atualize o arquivo publicado. `live` permanece ativo até uma nova alteração. A agenda é consultada a cada 60 segundos e ao retornar à aba; transições de horário são verificadas a cada segundo. Os horários são exibidos no fuso de Brasília.

Portal institucional estático, responsivo e orientado a dados, construído com HTML5, Bootstrap 5, CSS e JavaScript Vanilla ES Modules. Não há build, Node ou npm.

## Executar

Copie a pasta para `C:\xampp\htdocs\portal-pj\`, inicie o Apache no XAMPP e acesse `http://localhost/portal-pj/`. Não abra via `file://`: componentes e JSON usam `fetch()`.

Para desenvolvimento, qualquer servidor HTTP estático serve (por exemplo, `python -m http.server 8000`).

## Estrutura

- `components/`: header, footer e overlay de busca compartilhados.
- `assets/css/`: tokens e estilos customizados.
- `assets/js/`: módulos de componentes, navegação, busca, carrossel, soluções e documentos.
- `assets/images/`: imagens locais; substitua mantendo os caminhos ou atualize os JSON.
- `data/solutions.json`: adicione soluções e seus benefícios.
- `data/documents.json`: adicione documentos e caminhos em `pdfs/`.
- `data/search-index.json`: itens pesquisáveis.
- `pages/`: páginas internas.

Os PDFs de demonstração não estão incluídos; coloque os arquivos em `pdfs/` com os nomes configurados em `documents.json`. O formulário de contato apenas valida os campos até que uma URL de backend seja configurada.

## Publicação e URLs

A aplicação funciona em `/portal-pj/`. O `.htaccess` inclui uma regra opcional para `/portal-pj/solucoes/capital-giro`; requer `mod_rewrite`. A URL com query string (`pages/solucao.html?id=capital-giro`) funciona independentemente dessa regra.
