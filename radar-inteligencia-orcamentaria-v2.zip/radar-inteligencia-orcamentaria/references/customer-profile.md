# customer-profile

Use a população Empresas, se identificável. Valide granularidade conta/CNPJ e atribuição comercial; deduplique conforme regra corporativa. POSSUI_DESCONTOS=1 significa posse, não uso; 0 significa ausência conforme definição da fonte. Nulos não são zeros. Analise CNAE, idade da empresa (fundação confirmada), tempo de relacionamento e quantidade de outros produtos. Benchmark por perfil comparável: some população de cada estrato vezes penetração de referência; documente denominadores, amostras pequenas e cobertura. Se só houver clientes com desconto, não estime penetração.
