# performance-analysis

Filtre Ano_mes, NIVEL e JUNCAO antes de agregar. Use JUNCAG e JUNCGR para relacionar hierarquias conforme dicionário. Analise orc_Descontos e real_Descontos; para modalidades use os pares de cheque, duplicata, ordem de pagamento e outros. Não some total com componentes. Verifique reconciliação e informe diferenças. Compare períodos fechados ou cortes equivalentes; identifique maiores gaps e tendências. Não misture níveis hierárquicos.
