# budget-analysis

Atingimento = realizado/orçado quando orçado positivo; gap = orçado menos realizado. Para agregados use razão das somas de valores absolutos de unidades disjuntas. Não some percentuais. Compare participação no orçamento e no realizado dentro da mesma estrutura superior. Preserve orçamento original e vigente, se disponíveis. Confirme unidade de medida e escopo do indicador antes de estimar impacto financeiro.
