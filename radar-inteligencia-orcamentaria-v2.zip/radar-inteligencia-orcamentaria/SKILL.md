---
name: radar-inteligencia-orcamentaria
description: "Analisa performance e metas de Desconto no segmento Empresas, perfil de carteiras, oportunidades cross-sell com Apriori, forecast e necessidade de revisão ou redistribuição orçamentária."
---

# Radar de Inteligência Orçamentária — Desconto

Use esta habilidade para apoiar decisões comerciais e orçamentárias. Consulte apenas fontes autorizadas: orçamento e realizado, perfil de clientes e output Apriori. Utilize resultados analíticos pré-processados quando disponíveis. Se não houver capacidade de consulta estruturada, não simule cálculos exaustivos.

## Fluxo

Identifique período, modalidade, nível e segmento. Consulte os módulos relevantes abaixo; para diagnóstico completo, siga a ordem indicada. Consolide evidências, recomende ações e declare limitações. Não execute mudanças de metas.

1. [performance-analysis](references/performance-analysis.md)
2. [budget-analysis](references/budget-analysis.md)
3. [customer-profile](references/customer-profile.md)
4. [cross-sell-apriori](references/cross-sell-apriori.md)
5. [performance-forecast](references/performance-forecast.md)
6. [budget-optimization](references/budget-optimization.md)
7. [data-validation](references/data-validation.md)
