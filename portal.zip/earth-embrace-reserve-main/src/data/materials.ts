export interface SiteMaterial {
  title: string;
  description: string;
  file: string;
  date: string;
  keywords: string;
  page: "empresas";
}

export const siteMaterials: SiteMaterial[] = [
  {
    title: "Bem-vindo",
    description: "Conheça informações importantes, orientações e conteúdos preparados para sua empresa.",
    file: "/pdfs/exemplo.pdf",
    date: "2026-08-01",
    keywords: "boas-vindas apresentação portal pj exemplo documento pdf",
    page: "empresas",
  },
  {
    title: "Bem-vindo",
    description: "Página de onboarding com informações, orientações e conteúdos para sua empresa.",
    file: "/pdfs/onboarding.pdf",
    date: "2026-07-01",
    keywords: "onboarding integração orientações documento pdf",
    page: "empresas",
  },
];
