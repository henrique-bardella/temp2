import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import videoPoster from "@/assets/spot-lake.jpg";

const InstitutionalVideo = () => {
  const scrollToSolutions = () => {
    document.getElementById("locations")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="institutional-video" className="overflow-hidden bg-background py-20 lg:py-28" aria-labelledby="institutional-video-title">
      <div className="container mx-auto px-6 lg:px-12">
        <div className="grid items-stretch gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.7 }}
            className="flex flex-col justify-center py-6 lg:py-14"
          >
            <span className="mb-5 text-[11px] font-medium uppercase tracking-[0.2em] text-primary">
              Bradesco Empresas e Negócios
            </span>
            <h2
              id="institutional-video-title"
              className="max-w-xl text-4xl font-light leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-6xl"
            >
              Soluções feitas para o seu negócio
            </h2>
            <p className="mt-6 max-w-lg text-sm font-light leading-7 text-muted-foreground sm:text-base">
              Conte com um banco próximo, completo e preparado para apoiar cada etapa da sua empresa.
            </p>
            <button
              type="button"
              onClick={scrollToSolutions}
              className="mt-9 flex w-fit items-center gap-3 rounded-full bg-primary px-6 py-3 text-xs font-medium uppercase tracking-wider text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Conheça as soluções
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="relative min-h-[360px] overflow-hidden rounded-[2rem] bg-muted shadow-soft sm:min-h-[480px] lg:min-h-[620px]"
          >
            <video
              className="absolute inset-0 h-full w-full object-cover"
              controls
              preload="metadata"
              poster={videoPoster}
              playsInline
              aria-label="Vídeo institucional Bradesco Empresas e Negócios"
            >
              <source src="/videos/video-institucional.mp4" type="video/mp4" />
              Seu navegador não oferece suporte à reprodução de vídeo.
            </video>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default InstitutionalVideo;
