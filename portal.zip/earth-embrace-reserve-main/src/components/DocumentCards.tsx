import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpDown, ArrowUpRight, CalendarDays, FileText, LucideIcon } from "lucide-react";

export interface DocumentCardItem {
  title: string;
  description: string;
  file: string;
  date: string;
  icon?: LucideIcon;
}

interface DocumentCardsProps {
  eyebrow?: string;
  title: string;
  description?: string;
  documents: DocumentCardItem[];
}

const DocumentCards = ({ eyebrow, title, description, documents }: DocumentCardsProps) => {
  const [selectedMonth, setSelectedMonth] = useState("all");
  const [selectedYear, setSelectedYear] = useState("all");
  const [sortOrder, setSortOrder] = useState<"newest" | "oldest">("newest");

  const years = useMemo(
    () => Array.from(new Set(documents.map((document) => document.date.slice(0, 4)))).sort((a, b) => b.localeCompare(a)),
    [documents],
  );

  const months = useMemo(
    () => Array.from(new Set(documents.map((document) => document.date.slice(5, 7)))).sort(),
    [documents],
  );

  const visibleDocuments = useMemo(() => {
    return documents
      .filter((document) => selectedYear === "all" || document.date.startsWith(selectedYear))
      .filter((document) => selectedMonth === "all" || document.date.slice(5, 7) === selectedMonth)
      .sort((a, b) => sortOrder === "newest" ? b.date.localeCompare(a.date) : a.date.localeCompare(b.date));
  }, [documents, selectedMonth, selectedYear, sortOrder]);

  const formatDate = (date: string) => {
    const [year, month] = date.split("-").map(Number);
    return new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric" }).format(new Date(year, month - 1, 1));
  };

  const formatMonth = (month: string) => {
    return new Intl.DateTimeFormat("pt-BR", { month: "long" }).format(new Date(2026, Number(month) - 1, 1));
  };

  return (
    <section className="px-6 py-24 lg:px-12 lg:py-32" aria-labelledby="documents-title">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-14 max-w-2xl"
        >
          {eyebrow && (
            <span className="text-[11px] font-medium uppercase tracking-[0.2em] text-primary">
              {eyebrow}
            </span>
          )}
          <h1 id="documents-title" className="mt-3 text-3xl font-light tracking-tight md:text-4xl">
            {title}
          </h1>
          {description && (
            <p className="mt-4 text-sm font-light leading-7 text-muted-foreground">{description}</p>
          )}
        </motion.div>

        <div className="mb-8 flex flex-col gap-3 rounded-xl border border-border bg-secondary/40 p-4 sm:flex-row sm:items-center sm:justify-end">
          <div className="mr-auto flex items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            <CalendarDays className="h-4 w-4 text-primary" />
            Filtrar por data
          </div>
          <select
            value={selectedMonth}
            onChange={(event) => setSelectedMonth(event.target.value)}
            className="h-10 rounded-lg border border-border bg-card px-3 text-sm font-light text-foreground outline-none focus:border-primary/40 focus:ring-2 focus:ring-primary/10"
            aria-label="Filtrar documentos por mês"
          >
            <option value="all">Todos os meses</option>
            {months.map((month) => <option key={month} value={month}>{formatMonth(month)}</option>)}
          </select>
          <select
            value={selectedYear}
            onChange={(event) => setSelectedYear(event.target.value)}
            className="h-10 rounded-lg border border-border bg-card px-3 text-sm font-light text-foreground outline-none focus:border-primary/40 focus:ring-2 focus:ring-primary/10"
            aria-label="Filtrar documentos por ano"
          >
            <option value="all">Todos os anos</option>
            {years.map((year) => <option key={year} value={year}>{year}</option>)}
          </select>
          <label className="relative">
            <ArrowUpDown className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <select
              value={sortOrder}
              onChange={(event) => setSortOrder(event.target.value as "newest" | "oldest")}
              className="h-10 rounded-lg border border-border bg-card pl-9 pr-3 text-sm font-light text-foreground outline-none focus:border-primary/40 focus:ring-2 focus:ring-primary/10"
              aria-label="Ordenar documentos por data"
            >
              <option value="newest">Mais recentes</option>
              <option value="oldest">Mais antigos</option>
            </select>
          </label>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {visibleDocuments.map((document, index) => {
            const Icon = document.icon ?? FileText;
            return (
              <motion.a
                key={`${document.title}-${document.file}`}
                href={document.file}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                className="group flex min-h-64 flex-col rounded-xl border border-border bg-card p-8 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:border-primary/30 hover:shadow-lg"
                aria-label={`Abrir o documento ${document.title} em uma nova aba`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                  </div>
                  <ArrowUpRight
                    className="h-5 w-5 text-muted-foreground transition-all duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary"
                    aria-hidden="true"
                  />
                </div>
                <div className="mt-auto pt-12">
                  <span className="mb-3 inline-flex items-center gap-1.5 text-[11px] font-medium capitalize tracking-wide text-primary">
                    <CalendarDays className="h-3.5 w-3.5" aria-hidden="true" />
                    {formatDate(document.date)}
                  </span>
                  <h2 className="text-xl font-light tracking-tight text-foreground">{document.title}</h2>
                  <p className="mt-3 text-sm font-light leading-6 text-muted-foreground">
                    {document.description}
                  </p>
                  <span className="mt-5 inline-block text-[11px] font-medium uppercase tracking-wider text-primary">
                    Abrir PDF
                  </span>
                </div>
              </motion.a>
            );
          })}
        </div>

        {visibleDocuments.length === 0 && (
          <div className="rounded-xl border border-dashed border-border py-14 text-center">
            <p className="text-sm font-light text-muted-foreground">Nenhum documento encontrado para o período selecionado.</p>
            <button
              type="button"
              onClick={() => {
                setSelectedMonth("all");
                setSelectedYear("all");
              }}
              className="mt-4 text-xs font-medium uppercase tracking-wider text-primary hover:underline"
            >
              Limpar filtros
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default DocumentCards;
