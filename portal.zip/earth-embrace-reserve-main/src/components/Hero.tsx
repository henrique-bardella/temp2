import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ChevronLeft, ChevronRight, TreePine } from "lucide-react";
import heroImage from "@/assets/hero-camping.jpg";
import forestImage from "@/assets/spot-forest.jpg";
import antecipacao from "@/assets/antecipacao.jpg";
import lakeImage from "@/assets/spot-lake.jpg";
import meadowImage from "@/assets/spot-meadow.jpg";
import { useNavigate } from "react-router-dom";

const slides = [
  {
    image: heroImage,
    alt: "Empresas e negócios",
    eyebrow: "Portal PJ",
    title: ["Soluções para", "o seu negócio"],
    description: "Conteúdos e serviços pensados para apoiar sua empresa todos os dias.",
    buttonLabel: "Conheça o portal",
    href: "/empresas",
  },
  {
    image: antecipacao,
    alt: "Soluções para empresas",
    eyebrow: "Dia a Dia",
    title: ["Mais facilidade", "para sua empresa"],
    description: "Encontre soluções que tornam a gestão do seu negócio mais simples.",
    buttonLabel: "Ver soluções",
    href: "/locations",
  },
  {
    image: lakeImage,
    alt: "Conteúdo institucional",
    eyebrow: "Por dentro da PJ",
    title: ["Informação que", "aproxima"],
    description: "Conheça iniciativas, histórias e conteúdos do universo empresarial.",
    buttonLabel: "Saiba mais",
    href: "/about",
  },
  {
    image: meadowImage,
    alt: "Atendimento para empresas",
    eyebrow: "Fale com a matriz",
    title: ["Estamos aqui", "para ajudar"],
    description: "Acesse nossos canais e encontre o atendimento que sua empresa precisa.",
    buttonLabel: "Entre em contato",
    href: "/contact",
  },
];

const SLIDE_DURATION = 5000;

const Hero = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [progress, setProgress] = useState(0);

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
    setProgress(0);
  }, []);

  const previousSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
    setProgress(0);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
    setProgress(0);
  };

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          nextSlide();
          return 0;
        }
        return prev + (100 / (SLIDE_DURATION / 50));
      });
    }, 50);

    return () => clearInterval(progressInterval);
  }, [nextSlide]);

  return (
    <section className="relative h-screen w-full overflow-hidden">
      {/* Image Ticker */}
      <AnimatePresence mode="popLayout">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
          className="absolute inset-0"
        >
          <img
            src={slides[currentSlide].image}
            alt={slides[currentSlide].alt}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30" />
        </motion.div>
      </AnimatePresence>

      {/* Bottom-Left Text Content */}
      <div className="absolute bottom-20 left-6 md:left-12 lg:left-16 z-10 text-white">
        {/* Tree Icon */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="mb-4"
        >
          <TreePine className="w-6 h-6 text-white stroke-[1.5]" />
          <span className="mt-3 block text-[11px] font-medium uppercase tracking-[0.2em] text-white/80">
            {slides[currentSlide].eyebrow}
          </span>
        </motion.div>

        {/* Headline */}
        <motion.h1
          key={`title-${currentSlide}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-4xl md:text-5xl lg:text-6xl font-light tracking-tight max-w-md text-left flex flex-col"
        >
          <span>{slides[currentSlide].title[0]}</span>
          <span>{slides[currentSlide].title[1]}</span>
        </motion.h1>

        <motion.p
          key={`description-${currentSlide}`}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="mt-4 max-w-md text-sm font-light leading-6 text-white/85"
        >
          {slides[currentSlide].description}
        </motion.p>

        {/* CTA Button */}
        <motion.button
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          onClick={() => navigate(slides[currentSlide].href)}
          className="mt-6 flex items-center gap-3 bg-white text-foreground px-6 py-3 rounded-full text-sm tracking-wide hover:bg-white/90 transition-colors"
        >
          {slides[currentSlide].buttonLabel}
          <ArrowRight className="w-4 h-4" />
        </motion.button>
      </div>

      {/* Previous and Next Controls */}
      <div className="absolute bottom-20 right-6 z-20 flex items-center gap-3 md:right-12 lg:right-16">
        <button
          type="button"
          onClick={previousSlide}
          aria-label="Imagem anterior"
          className="flex h-11 w-11 items-center justify-center rounded-full border border-white/40 bg-black/20 text-white backdrop-blur-md transition-all hover:border-white hover:bg-white hover:text-foreground"
        >
          <ChevronLeft className="h-5 w-5" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={nextSlide}
          aria-label="Próxima imagem"
          className="flex h-11 w-11 items-center justify-center rounded-full border border-white/40 bg-black/20 text-white backdrop-blur-md transition-all hover:border-white hover:bg-white hover:text-foreground"
        >
          <ChevronRight className="h-5 w-5" aria-hidden="true" />
        </button>
      </div>

      {/* Progress Bars */}
      <div className="absolute bottom-8 left-6 md:left-12 lg:left-16 right-6 md:right-12 lg:right-16 z-10 flex gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className="flex-1 h-[2px] bg-white/30 overflow-hidden cursor-pointer"
            aria-label={`Go to slide ${index + 1}`}
          >
            <div
              className="h-full bg-white transition-all duration-100 ease-linear"
              style={{
                width: index === currentSlide ? `${progress}%` : index < currentSlide ? "100%" : "0%",
              }}
            />
          </button>
        ))}
      </div>
    </section>
  );
};

export default Hero;
