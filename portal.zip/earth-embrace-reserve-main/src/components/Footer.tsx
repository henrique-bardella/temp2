import { Link } from "react-router-dom";
import bradescoLogo from "@/assets/bradesco-empresas-logo.png";

const linkClass = "text-sm font-light text-muted-foreground transition-colors hover:text-primary";

const Footer = () => {
  return (
    <footer className="border-t border-border bg-secondary/50 text-foreground">
      <div className="container mx-auto px-6 py-14 lg:px-12 lg:py-16">
        <div className="grid gap-12 md:grid-cols-[1.5fr_1fr_1fr_1fr] md:gap-8">
          <div className="flex items-start">
            <Link to="/" aria-label="Bradesco Empresas e Negócios - início">
              <img
                src={bradescoLogo}
                alt="Bradesco Empresas e Negócios"
                className="h-12 w-auto object-contain"
              />
            </Link>
          </div>

          <div>
            <h3 className="mb-5 text-xs font-semibold uppercase tracking-wider">Navegação</h3>
            <div className="mb-5 h-0.5 w-10 bg-primary" />
            <ul className="space-y-3">
              <li><Link to="/" className={linkClass}>Início</Link></li>
              <li><Link to="/locations" className={linkClass}>Soluções</Link></li>
              <li><a href="/#booking" className={linkClass}>Fale com a gente</a></li>
            </ul>
          </div>

          <div>
            <h3 className="mb-5 text-xs font-semibold uppercase tracking-wider">Institucional</h3>
            <div className="mb-5 h-0.5 w-10 bg-primary" />
            <ul className="space-y-3">
              <li><Link to="/about" className={linkClass}>Sobre nós</Link></li>
              <li><a href="/#experience" className={linkClass}>Experiência</a></li>
            </ul>
          </div>

          <div>
            <h3 className="mb-5 text-xs font-semibold uppercase tracking-wider">Atendimento</h3>
            <div className="mb-5 h-0.5 w-10 bg-primary" />
            <ul className="space-y-3">
              <li><Link to="/contact" className={linkClass}>Contato</Link></li>
              <li><Link to="/contact" className={linkClass}>Central de ajuda</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-border pt-7 text-center">
          <p className="text-xs font-light text-muted-foreground">
            &copy; 2026 Bradesco Empresas e Negócios. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
