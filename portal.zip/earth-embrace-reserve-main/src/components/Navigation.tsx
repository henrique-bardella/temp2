import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, FileText, Menu, Search, X } from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import bradescoLogo from "@/assets/bradesco-empresas-logo.png";
import { siteMaterials } from "@/data/materials";

interface NavigationProps {
  variant?: "default" | "dark";
}

interface SubItem {
  label: string;
  href: string;
  sectionId?: string;
  items?: SubItem[];
}

interface NavItem {
  label: string;
  items: SubItem[];
}

interface SearchItem extends SubItem {
  description: string;
  keywords: string;
}

const navItems: NavItem[] = [
  {
    label: "Portal PJ",
    items: [
      { label: "Página inicial", href: "/" },
      { label: "Empresas", href: "/empresas" },
      { label: "Sobre o portal", href: "/about" },
    ],
  },
  {
    label: "Dia a Dia",
    items: [
      {
        label: "Soluções",
        href: "/locations",
        items: [
          { label: "Todas as soluções", href: "/locations" },
          { label: "Gestão do negócio", href: "/location/forest" },
          { label: "Crédito e investimentos", href: "/location/lake" },
          { label: "Serviços para empresas", href: "/location/meadow" },
        ],
      },
      { label: "Experiência", href: "/", sectionId: "experience" },
      { label: "Agendamentos", href: "/", sectionId: "booking" },
    ],
  },
  {
    label: "Links úteis",
    items: [
      { label: "Documentos", href: "/empresas" },
      { label: "Soluções em destaque", href: "/", sectionId: "locations" },
    ],
  },
  {
    label: "Meus Resultados",
    items: [
      { label: "Visão geral", href: "/empresas" },
      { label: "Relatórios", href: "/empresas" },
    ],
  },
  {
    label: "Por dentro da PJ",
    items: [
      { label: "Conteúdos", href: "/empresas" },
      { label: "Nossa história", href: "/about" },
      { label: "Vídeo institucional", href: "/", sectionId: "institutional-video" },
    ],
  },
  {
    label: "Fale com a matriz",
    items: [
      { label: "Entre em contato", href: "/contact" },
      { label: "Central de ajuda", href: "/contact" },
    ],
  },
];

const pageSearchItems: SearchItem[] = [
  { label: "Página inicial", href: "/", description: "Início do Portal PJ", keywords: "home portal pj bradesco" },
  { label: "Empresas", href: "/empresas", description: "Conteúdos e documentos para empresas", keywords: "empresa pj documentos" },
  { label: "Soluções", href: "/locations", description: "Soluções para o dia a dia do negócio", keywords: "produtos serviços negócios" },
  { label: "Sobre o portal", href: "/about", description: "Informações institucionais", keywords: "história institucional sobre" },
  { label: "Experiência", href: "/", sectionId: "experience", description: "Conheça a experiência do portal", keywords: "experiência benefícios" },
  { label: "Vídeo institucional", href: "/", sectionId: "institutional-video", description: "Assista ao vídeo institucional", keywords: "vídeo filme apresentação" },
  { label: "Agendamentos", href: "/", sectionId: "booking", description: "Acesse a área de agendamentos", keywords: "agenda reserva atendimento" },
  { label: "Fale com a matriz", href: "/contact", description: "Canais de contato e ajuda", keywords: "contato matriz ajuda atendimento" },
];

const materialSearchItems: SearchItem[] = siteMaterials.map((material) => ({
  label: material.title,
  href: material.file,
  description: `${material.description} · ${new Intl.DateTimeFormat("pt-BR", { month: "long", year: "numeric" }).format(new Date(`${material.date}T12:00:00`))}`,
  keywords: `${material.keywords} ${material.file} ${material.date}`,
}));

const searchItems = [...pageSearchItems, ...materialSearchItems];

const Navigation = ({ variant = "default" }: NavigationProps) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const navigationRef = useRef<HTMLElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const location = useLocation();
  const navigate = useNavigate();
  const isDark = variant === "dark";
  const isHomePage = location.pathname === "/";
  const useLightText = !isScrolled && !isMobileMenuOpen;

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    const handleOutsideClick = (event: MouseEvent) => {
      if (!navigationRef.current?.contains(event.target as Node)) {
        setOpenMenu(null);
        setIsSearchOpen(false);
      }
    };

    handleScroll();
    window.addEventListener("scroll", handleScroll);
    document.addEventListener("mousedown", handleOutsideClick);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      document.removeEventListener("mousedown", handleOutsideClick);
    };
  }, []);

  useEffect(() => {
    setOpenMenu(null);
    setOpenSubmenu(null);
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (isSearchOpen) window.setTimeout(() => searchInputRef.current?.focus(), 100);
  }, [isSearchOpen]);

  const goToSection = (sectionId: string) => {
    const scroll = () => document.getElementById(sectionId)?.scrollIntoView({ behavior: "smooth" });
    if (isHomePage) scroll();
    else {
      navigate("/");
      window.setTimeout(scroll, 150);
    }
    setOpenMenu(null);
    setIsMobileMenuOpen(false);
  };

  const textColor = useLightText ? "text-white" : "text-foreground";
  const mobileBackground = "bg-card";
  const normalizedQuery = searchQuery.trim().toLocaleLowerCase("pt-BR");
  const searchResults = normalizedQuery
    ? searchItems.filter((item) =>
        `${item.label} ${item.description} ${item.keywords}`.toLocaleLowerCase("pt-BR").includes(normalizedQuery),
      )
    : [];

  const renderSubItem = (item: SubItem, mobile = false) => {
    const className = mobile
      ? `block w-full py-2.5 pl-4 text-left text-xs font-light ${textColor} hover:opacity-60 smooth-hover`
      : "block w-full whitespace-nowrap px-5 py-3 text-left text-xs font-light text-foreground hover:bg-accent hover:text-accent-foreground smooth-hover";

    if (item.items?.length) {
      const isSubmenuOpen = openSubmenu === item.label;
      return (
        <div key={item.label} className={mobile ? "border-t border-border/60 first:border-0" : "border-t border-border first:border-0"}>
          <button
            type="button"
            aria-expanded={isSubmenuOpen}
            className={`${className} flex items-center justify-between gap-4`}
            onClick={() => setOpenSubmenu(isSubmenuOpen ? null : item.label)}
          >
            <span>{item.label}</span>
            <ChevronDown className={`h-3.5 w-3.5 transition-transform duration-300 ${isSubmenuOpen ? "rotate-180" : ""}`} />
          </button>
          <AnimatePresence initial={false}>
            {isSubmenuOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className={`overflow-hidden ${mobile ? "ml-4 border-l border-primary/20" : "bg-secondary/50"}`}
              >
                {item.items.map((child) => renderSubItem(child, mobile))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      );
    }

    if (item.sectionId) {
      return (
        <button key={item.label} type="button" className={className} onClick={() => goToSection(item.sectionId!)}>
          {item.label}
        </button>
      );
    }

    return (
      <Link key={item.label} to={item.href} className={className} onClick={() => {
        setOpenMenu(null);
        setIsMobileMenuOpen(false);
      }}>
        {item.label}
      </Link>
    );
  };

  return (
    <motion.nav
      ref={navigationRef}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
      className={`fixed inset-x-0 top-0 z-[100] transition-all duration-400 ${
        isMobileMenuOpen
          ? "bg-card"
          : isScrolled || isDark
            ? "bg-card/95 backdrop-blur-lg shadow-soft"
            : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-6 py-5 lg:px-12">
        <div className="relative flex items-center justify-between">
          <Link to="/" aria-label="Bradesco Empresas e Negócios - início">
            <motion.div whileHover={{ scale: 1.02 }} className="flex cursor-pointer items-center gap-2">
              <img
                src={bradescoLogo}
                alt="Bradesco Empresas e Negócios"
                className="h-11 w-auto object-contain sm:h-12"
              />
            </motion.div>
          </Link>

          <div className="absolute left-1/2 hidden -translate-x-1/2 items-center gap-4 xl:gap-6 xl:flex">
            {navItems.map((item) => {
              const isOpen = openMenu === item.label;
              return (
                <div key={item.label} className="relative">
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    aria-haspopup="menu"
                    onClick={() => {
                      setOpenMenu(isOpen ? null : item.label);
                      setOpenSubmenu(null);
                    }}
                    className={`flex items-center gap-1.5 whitespace-nowrap text-[11px] font-normal uppercase tracking-wider hover:opacity-60 smooth-hover ${textColor}`}
                  >
                    {item.label}
                    <ChevronDown className={`h-3 w-3 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
                  </button>
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        role="menu"
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 8 }}
                        transition={{ duration: 0.2 }}
                        className="absolute left-1/2 top-full mt-5 min-w-52 -translate-x-1/2 overflow-hidden rounded-lg border border-border bg-card py-2 shadow-xl"
                      >
                        {item.items.map((subItem) => renderSubItem(subItem))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>

          <div className="ml-auto flex items-center gap-4">
            <button
              type="button"
              aria-label={isSearchOpen ? "Fechar busca" : "Abrir busca"}
              aria-expanded={isSearchOpen}
              className={`rounded-full p-2 transition-colors hover:bg-primary/10 hover:text-primary ${textColor}`}
              onClick={() => {
                setIsSearchOpen(!isSearchOpen);
                setOpenMenu(null);
                setIsMobileMenuOpen(false);
              }}
            >
              {isSearchOpen ? <X className="h-5 w-5" /> : <Search className="h-5 w-5" />}
            </button>
            <button
              type="button"
              aria-label={isMobileMenuOpen ? "Fechar menu" : "Abrir menu"}
              aria-expanded={isMobileMenuOpen}
              className={`xl:hidden ${textColor}`}
              onClick={() => {
                setIsMobileMenuOpen(!isMobileMenuOpen);
                setIsSearchOpen(false);
                setOpenMenu(null);
              }}
            >
              {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {isSearchOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className="absolute left-0 right-0 top-full bg-transparent"
            >
              <div className="container mx-auto px-6 py-6 lg:px-12">
                <div className="relative mx-auto max-w-3xl">
                  <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <input
                    ref={searchInputRef}
                    type="search"
                    value={searchQuery}
                    onChange={(event) => setSearchQuery(event.target.value)}
                    placeholder="O que você está procurando?"
                    className="h-12 w-full rounded-full border border-border bg-background pl-11 pr-5 text-sm font-light text-foreground outline-none transition-shadow placeholder:text-muted-foreground focus:border-primary/40 focus:ring-4 focus:ring-primary/10"
                  />
                </div>

                {normalizedQuery && (
                  <div className="mx-auto mt-4 max-h-72 max-w-3xl overflow-y-auto rounded-xl border border-border bg-card p-2">
                    {searchResults.length > 0 ? (
                      searchResults.map((item) => {
                        const content = (
                          <>
                            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary/10">
                              {item.href.endsWith(".pdf") ? <FileText className="h-4 w-4 text-primary" /> : <Search className="h-4 w-4 text-primary" />}
                            </span>
                            <span>
                              <span className="block text-sm font-normal text-foreground">{item.label}</span>
                              <span className="mt-0.5 block text-xs font-light text-muted-foreground">{item.description}</span>
                            </span>
                          </>
                        );

                        const resultClass = "flex w-full items-center gap-3 rounded-lg px-3 py-3 text-left transition-colors hover:bg-accent";
                        if (item.sectionId) {
                          return <button key={item.label} type="button" className={resultClass} onClick={() => {
                            setIsSearchOpen(false);
                            setSearchQuery("");
                            goToSection(item.sectionId!);
                          }}>{content}</button>;
                        }

                        return (
                          <a
                            key={item.label}
                            href={item.href}
                            target={item.href.endsWith(".pdf") ? "_blank" : undefined}
                            rel={item.href.endsWith(".pdf") ? "noopener noreferrer" : undefined}
                            className={resultClass}
                            onClick={() => {
                              setIsSearchOpen(false);
                              setSearchQuery("");
                            }}
                          >
                            {content}
                          </a>
                        );
                      })
                    ) : (
                      <p className="px-4 py-6 text-center text-sm font-light text-muted-foreground">
                        Nenhum resultado encontrado.
                      </p>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, clipPath: "inset(0 0 100% 0)" }}
              animate={{ opacity: 1, clipPath: "inset(0 0 0% 0)" }}
              exit={{ opacity: 0, clipPath: "inset(0 0 100% 0)" }}
              transition={{ duration: 0.45, ease: [0.4, 0, 0.2, 1] }}
              className={`-mx-6 mt-6 rounded-b-xl px-6 pb-4 xl:hidden ${mobileBackground}`}
            >
              {navItems.map((item) => {
                const isOpen = openMenu === item.label;
                return (
                  <div key={item.label} className="border-b border-border last:border-0">
                    <button
                      type="button"
                      aria-expanded={isOpen}
                      onClick={() => {
                        setOpenMenu(isOpen ? null : item.label);
                        setOpenSubmenu(null);
                      }}
                      className={`flex w-full items-center justify-between whitespace-nowrap py-4 text-[11px] font-normal uppercase tracking-wider ${textColor}`}
                    >
                      {item.label}
                      <ChevronDown className={`h-3.5 w-3.5 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`} />
                    </button>
                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="overflow-hidden pb-2"
                        >
                          {item.items.map((subItem) => renderSubItem(subItem, true))}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.nav>
  );
};

export default Navigation;
