import { motion, useScroll, useTransform } from "framer-motion";
import { Handshake } from "lucide-react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import DocumentCards from "@/components/DocumentCards";
import bannerImage from "@/assets/detail-forest-1.jpg";
import { siteMaterials } from "@/data/materials";

const documents = siteMaterials
  .filter((material) => material.page === "empresas")
  .map((material) => ({ ...material, icon: Handshake }));

const Empresas = () => {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 150]);

  return (
    <div className="min-h-screen overflow-x-hidden bg-background">
      <Navigation />

      <header className="relative h-[50vh] min-h-[420px] w-full overflow-hidden">
        <motion.img
          src={bannerImage}
          alt="Empresas e negócios"
          style={{ y }}
          initial={{ opacity: 0, scale: 1.08 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.1 }}
          className="absolute inset-0 h-[120%] w-full object-cover"
        />
        <div className="absolute inset-0 bg-black/45" />
        <div className="container relative z-10 mx-auto flex h-full items-end px-6 pb-14 text-white lg:px-12 lg:pb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <span className="text-[11px] font-medium uppercase tracking-[0.2em] text-white/75">
              Bradesco Empresas e Negócios
            </span>
            <h1 className="mt-3 text-4xl font-light tracking-tight md:text-5xl">Empresas</h1>
          </motion.div>
        </div>
      </header>

      <main>
        <DocumentCards
          eyebrow="Conteúdos para sua empresa"
          title="Informações e documentos"
          description="Acesse materiais úteis preparados para apoiar o dia a dia do seu negócio."
          documents={documents}
        />
      </main>

      <Footer />
    </div>
  );
};

export default Empresas;
