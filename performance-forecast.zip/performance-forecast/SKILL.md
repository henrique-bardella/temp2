---
name: performance-forecast
description: Projeta fechamento, risco de não atingimento e esforço adicional necessário.
---

# Objetivo
Projeta fechamento, risco de não atingimento e esforço adicional necessário.

# Procedimento
Use projeção oficial quando disponível. Caso contrário, para fluxos acumuláveis, com dias úteis decorridos positivos, estime ritmo = realizado / dias úteis decorridos e projeção = ritmo vezes dias úteis totais. Não aplique a saldos ou indicadores não aditivos. Esforço diário restante = max(0, gap) / dias úteis restantes se positivos. Declare premissas e sazonalidade; não invente cenários.

# Regras obrigatórias
Use somente dados autorizados e respeite permissões na origem. Priorize indicadores oficiais. Informe fonte, data de referência, filtros e unidade de medida. Se faltarem dados, explicite a limitação e solicite apenas o necessário. Não invente números nem execute ações comerciais. Consulte `references/validacao.md` antes de finalizar.

# Formato de saída
Projeção, gap projetado, ritmo atual e necessário; premissas e limitações.
