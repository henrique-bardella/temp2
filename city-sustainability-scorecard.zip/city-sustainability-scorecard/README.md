# City Sustainability Scorecard 🏙️🏆

**My Round I entry for the Power BI World Championship 2026**, the report that carried me through to the World Final.

This is the championship report, adapted for public sharing. The full model, the extracted source, every DAX measure and the curated HTML components are all here for you to study and reuse.

![City Sustainability Scorecard · Home](docs/screenshots/home.png)

## Download

Grab **[City Sustainability Scorecard (World Champs 26).pbix](City%20Sustainability%20Scorecard%20(World%20Champs%2026).pbix)** and open it in Power BI Desktop. Everything ships inside: model, data, theme, HTML components, navigation and the embedded tutorial. No external data source to connect, the data is held in the model.

![Executive Summary](docs/screenshots/executive-summary.png)

## What is inside

| Area | What you will find |
|---|---|
| `dax/` | All 223 measures as standalone `.dax` files, one per file, grouped into 14 display folders (see `dax/README.md`). Normalisation and composite scoring, ranking and gap logic, temporal and year on year analysis, field parameter driven layers, and screen reader alt text for every visual |
| `html-components/` | 74 HTML component templates extracted from the report, with their CSS split into `html-components/css/`. Cards, panels, radar, sparklines and headers. `<!--{DAX}-->` marks where the report injects dynamic values |
| `src/Model/` | The complete semantic model in TMDL: the `_Measures` table, City Metrics, City Lookup, slicer and parameter tables, and the relationships |
| `src/Report/` | Report layout, sections and the full bookmark set that drives the multi page guided tutorial |
| `src/StaticResources/` | The theme file and registered image resources. The theme JSON carries more than colours: button presets, visual styles and design tokens are set at theme level so visuals inherit the design instead of being formatted one by one |
| `src/CustomVisuals/` | The one third party visual used, HTML Content by Daniel Marsh-Patrick, vendored for reference |

## How the DAX is organised

Every measure lives in a themed folder so a first time reader can navigate by intent, not by scrolling one long list.

| Folder | What lives here |
|---|---|
| `01-accessibility-alt-text/` | Screen reader alt text measures for every visual |
| `02-tutorial-walkthrough/` | In report guided tutorial step content |
| `03-field-parameters/` | Field parameter driven icon and description logic |
| `04-html-panels/` | Filter, notifications and insight panel HTML |
| `05-html-cards/` | KPI and rank card HTML templates |
| `06-html-visuals/` | Radar, sparkline, headers and video intro HTML |
| `07-normalisation-scoring/` | Metric normalisation and composite scoring |
| `08-dimensions-strongest-weakest/` | Strongest and weakest dimension logic |
| `09-ranking/` | City rank, gap and ranking display measures |
| `10-temporal-analysis/` | Trend, year on year, peak and lowest year, period change |
| `11-colours-and-icons/` | Conditional colour and icon selection |
| `12-titles-and-text/` | Dynamic titles, subtitles and context strings |
| `13-metrics-and-aggregates/` | Base averages, benchmarks and metric selection |
| `14-helpers/` | Small utility and placeholder measures |

## The approach, in short

The report was designed before Power BI opened. It mixes native Power BI visuals for the charts with HTML components rendered from DAX for the cards, panels and headers, so the bespoke pieces are authored like front end templates and fed dynamic values from the model. Metrics are normalised to a common scale before they are composited, so a single livability score stays honest across very different units. Field parameters drive the dynamic layer instead of bookmark sprawl, and every visual carries an alt text measure for accessibility.

Want more resources like this? Follow along and become a member at [gusbavia.com](https://www.gusbavia.com)

## Data

The dataset is illustrative city sustainability data, held inside the model in Power Query. There is nothing external to connect. Open the file and it just works.

## Reusing the components

1. Open any template in `html-components/` next to its stylesheet in `html-components/css/`
2. Replace each `<!--{DAX}-->` marker with your own value, colour token or measure output
3. In Power BI, feed the assembled string to an HTML rendering visual sized to the same container proportions

The originals in `src/Model/tables/_Measures.tmdl` show the full working DAX that assembles each component dynamically.

## Licence

MIT. Use it, learn from it, ship your own version. A mention is appreciated but not required.

---

**Gus Bavia** · [gusbavia.com](https://www.gusbavia.com) · [LinkedIn](https://www.linkedin.com/in/gusbavia)
*Power BI World Championship 2026*
