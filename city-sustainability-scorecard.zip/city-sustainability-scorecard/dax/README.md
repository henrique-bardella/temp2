# DAX measures

Every measure from the `_Measures` table, one file per measure, grouped into display folders.

| Folder | What lives here | Measures |
| --- | --- | --- |
| `01-accessibility-alt-text/` | Screen-reader alt-text measures for every visual | 24 |
| `02-tutorial-walkthrough/` | In-report guided tutorial step content | 23 |
| `03-field-parameters/` | Field parameter driven icon and description logic | 2 |
| `04-html-panels/` | Filter, notifications and insight panel HTML | 4 |
| `05-html-cards/` | KPI and rank card HTML templates | 16 |
| `06-html-visuals/` | Radar, sparkline, headers and video intro HTML | 7 |
| `07-normalisation-scoring/` | Metric normalisation and composite scoring | 7 |
| `08-dimensions-strongest-weakest/` | Strongest and weakest dimension logic | 6 |
| `09-ranking/` | City rank, gap and ranking display measures | 18 |
| `10-temporal-analysis/` | Trend, YoY, peak/lowest year and period change | 47 |
| `11-colours-and-icons/` | Conditional colour and icon selection | 16 |
| `12-titles-and-text/` | Dynamic titles, subtitles and context strings | 24 |
| `13-metrics-and-aggregates/` | Base averages, benchmarks and metric selection | 19 |
| `14-helpers/` | Small utility and placeholder measures | 10 |
